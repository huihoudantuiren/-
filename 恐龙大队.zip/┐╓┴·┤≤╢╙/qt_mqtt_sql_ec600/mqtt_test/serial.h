#ifndef SERIAL_H
#define SERIAL_H
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QTimer>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <linux/types.h>
#include <sys/ioctl.h>
#include <QWidget>
#include <QCoreApplication>
#include <iostream>
#include <QStringList>
#include <QString>
#include <QVariant>
#include <QDebug>
#include <QDateTime>
#include <QTime>
#include <QTimer>
#include <QDebug>
#include "serial.h"

#define usb_4G "/dev/ttyS1"
#define usb_lora "/dev/ttyS2"
class Serial
{
public:
    Serial();  // 构造函数
    ~Serial(); // 析构函数
    void sendMqttMessage(const QByteArray &message);
    QByteArray readFromSerialPort(const QString &portName);
    bool writeToSerialPort(const QString &portName, const QByteArray &message);
    void listPorts();                      // 列出所有可用串口
    bool initializePort(const QString &portName); // 初始化指定的串口
    bool writeData(const QString &portName, const QByteArray &data); // Write data to the specified serial port
    void init_4G();
    void init_lora();
    QByteArray readData(const QString &portName);                   // Read data from the specified serial port
private:
    QSerialPort serial;
    QSerialPort* getSerialPort(const QString &portName);

};

#endif // SERIAL_H
