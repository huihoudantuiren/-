#ifndef _CORE_ADAPTER_H_
#define _CORE_ADAPTER_H_

#if defined(__cplusplus)
extern "C" {
#endif

#include "core_stdinc.h"
#include "aiot_sysdep_api.h"

#if defined(__cplusplus)
}
#endif

#endif
