#ifndef DATA_MODEL_BASIC_DEMO_H
#define DATA_MODEL_BASIC_DEMO_H
#ifdef __cplusplus

extern "C" {

#endif

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "mqtt_sdk/aiot_state_api.h"
#include "mqtt_sdk/aiot_sysdep_api.h"
#include "mqtt_sdk/aiot_mqtt_api.h"
#include "mqtt_sdk/aiot_dm_api.h"

extern void *mqtt_handle;
extern int msg_flag;
int init_mqtt();
#ifdef __cplusplus

}

#endif

#endif
