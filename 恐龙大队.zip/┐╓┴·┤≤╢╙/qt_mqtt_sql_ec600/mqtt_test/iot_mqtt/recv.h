#ifndef RECV_H
#define RECV_H


class recv
{
public:
    recv();
};

#endif // RECV_H