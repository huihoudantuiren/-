#ifndef LORA_H
#define LORA_H

#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QTimer>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <linux/types.h>
#include <sys/ioctl.h>
#include <QWidget>
#include <QCoreApplication>
#include <iostream>
#include <QStringList>
#include <QString>
#include <QVariant>
#include <QDebug>
#include <QDateTime>
#include <QTime>
#include <QTimer>
#include <QDebug>


#define uart_lora "/dev/ttyS2"

class lora
{
public:
    lora();
    ~lora();
    void sendloraMessage(const QByteArray &message);
    QByteArray readFromSerialPort(const QString &portName);
    bool writeToSerialPort(const QString &portName, const QByteArray &message);
    void listPorts();                      // 鍒楀嚭鎵€鏈夊彲鐢ㄤ覆鍙?
    bool initializePort(const QString &portName); // 鍒濆鍖栨寚瀹氱殑涓插彛
    bool writeData(const QString &portName, const QByteArray &data); // Write data to the specified serial port
    void init_lora();
    QByteArray readData(const QString &portName);                   // Read data from the specified serial port
private:
    QSerialPort serial;
    QSerialPort* getSerialPort(const QString &portName);
};

#endif // LORA_H
