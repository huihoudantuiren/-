#ifndef PAST_RECORDS_H
#define PAST_RECORDS_H

#include <QWidget>
#include <widget.h>

#include <QCoreApplication>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlRecord>
#include <iostream>
#include <QStringList>
#include <QString>
#include <QVariant>
#include <QDebug>
#include <QDateTime>
#include <QTime>
#include <QTimer>
#include <QDebug>
#include <QNetworkConfigurationManager>
#include "serial.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QtSql>
#include <QtCharts>
#include <QDateTime>
using namespace QtCharts;
namespace Ui {
class past_records;
}
using namespace QtCharts;
class past_records : public QWidget
{
    Q_OBJECT

public:
    explicit past_records(QWidget *parent = nullptr);
    ~past_records();

signals:
    void back();

private slots:
    void on_pushButton_clicked();
    void InitChart();
    void on_pushButton_2_clicked();
    void plotArrayData(const QVector<QString>& datetimes, const QVector<int>& temperatures);
    void plotArrayData_sishi(const QVector<QString>& datetimes, const QVector<int>& temperatures);
    void timer_sishi();
    void timer_task();
    void on_pushButton_3_clicked();

private:
    Ui::past_records *ui;
    QTimer *timer;
};

#endif // PAST_RECORDS_H
