#include "widget.h"
#include "ui_widget.h"
#include "iot_mqtt/data_model_basic_demo.h"
#include "iot_mqtt/mqtt_sdk/aiot_mqtt_api.h"
#include "lora.h"

#include <QtGlobal>
QByteArray receivedData_lora;

pthread_t ntid;
QByteArray receivedData_4G;
uint8_t re;
void request_data(int i,int zd_index);
QString date_time_temp ;//获取时间
int temprature_value_temp = 23;
int light_value_temp = 2000;
int humidity_value_temp = 72;
int fog_value_temp = 144;
int dust_value_temp = 40;

int temprature_value_temp_lora = 23;
int light_value_temp_lora = 20;
int humidity_value_temp_lora = 72;
int fog_value_temp_lora = 900;
int dust_value_temp_lora = 4;

int temprature_value_temp_lora_A = 23;
int light_value_temp_lora_A = 20;
int humidity_value_temp_lora_A = 72;
int fog_value_temp_lora_A = 900;
int dust_value_temp_lora_A = 4;


int temprature_value_temp_lora_B = 23;
int light_value_temp_lora_B = 2000;
int humidity_value_temp_lora_B = 72;
int fog_value_temp_lora_B = 900;
int dust_value_temp_lora_B = 4;

int temprature_value_temp_lora_C = 23;
int light_value_temp_lora_C = 2000;
int humidity_value_temp_lora_C = 72;
int fog_value_temp_lora_C = 144;
int dust_value_temp_lora_C = 40;



int index1=0;
int index2=0;
int index3=0;

int zd_i=1;
int zd_ind=1;
void print_numbers();
void *receive( void *arg ) {

    while(1){
        if(0!=msg_flag&&re){
            qDebug()<<msg_data;
            qDebug()<<"receive";
            msg_flag=0;
        }
//        print_numbers();
    }
    return((void *)0);
}
class ReceiverThread : public QThread {
    void run() override {
        receive(nullptr);
    }
};

int rec_flag=1;
int jiedong=1;
void print_numbers() {
//    if(rec_flag==2)
//    {
        lora lora;
        QString portName = uart_lora;
        QByteArray receivedData = lora.readFromSerialPort(portName);
        qDebug() << "try to Received loradata";

        if (!receivedData.isEmpty()) {
            jiedong=0;
            qDebug() << "Received data from" << portName << ":" << receivedData;
            receivedData_lora = receivedData.mid(2,4);
            qDebug() << "Received data:" << receivedData;
            if(receivedData.mid(6,4).toInt()!=9999||receivedData.mid(6,4).toInt()!=0){
            if(receivedData.mid(2,4)=="0A01"){
                temprature_value_temp_lora_A = (int)(receivedData.mid(6,4).toInt()/100);
            }
            else if(receivedData.mid(2,4)=="0A02"){
                humidity_value_temp_lora_A = (int)receivedData.mid(6,4).toInt()/100;
            }
            else if(receivedData.mid(2,4)=="0A03"){
                fog_value_temp_lora_A = (int)(10000 - receivedData.mid(6,4).toInt()*10);
            }
            else if(receivedData.mid(2,4)=="0A04"){
                dust_value_temp_lora_A = receivedData.mid(6,4).toInt()/10;
            }
            else if(receivedData.mid(2,4)=="0A05"){
                light_value_temp_lora_A = (int)(100 - receivedData.mid(6,4).toInt()/49);
            }
            else if(receivedData.mid(2,4)=="0B01"){
                temprature_value_temp_lora_B = (int)receivedData.mid(6,4).toInt()/100;
            }
            else if(receivedData.mid(2,4)=="0B02"){
                humidity_value_temp_lora_B = receivedData.mid(6,4).toInt()/100;
            }
            else if(receivedData.mid(2,4)=="0B03"){
                fog_value_temp_lora_B = (int)(10000 - receivedData.mid(6,4).toInt()*10);
            }
            else if(receivedData.mid(2,4)=="0B04"){
                dust_value_temp_lora_B = receivedData.mid(6,4).toInt()/10;
            }
            else if(receivedData.mid(2,4)=="0B05"){
                light_value_temp_lora_B = (int)(100 - receivedData.mid(6,4).toInt()/49);
            }
            else if(receivedData.mid(2,4)=="0C01"){
                temprature_value_temp_lora_C = (int)receivedData.mid(6,4).toInt()/100;
            }
            else if(receivedData.mid(2,4)=="0C02"){
                humidity_value_temp_lora_C = receivedData.mid(6,4).toInt()/100;
            }
            else if(receivedData.mid(2,4)=="0C03"){
                fog_value_temp_lora_C = (int)(10000 - receivedData.mid(6,4).toInt()*10);
            }
            else if(receivedData.mid(2,4)=="0C04"){
                dust_value_temp_lora_C = receivedData.mid(6,4).toInt()/10;
            }
            else if(receivedData.mid(2,4)=="0C05"){
                light_value_temp_lora_C = (int)(100 - receivedData.mid(6,4).toInt()/49);
            }
            }
            }
        rec_flag=1;
//        }

//        usleep(510401); // 每隔500ms输出

}

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    int rs=0;
    int err = pthread_create(&ntid, NULL, receive, &msg_flag);
    if (err != 0)
        qDebug()<<"tid_error";
    ReceiverThread *thread = new ReceiverThread();
    connect(thread, &QThread::finished, thread, &QObject::deleteLater);
    thread->start();
    rs=init_mqtt();
    InitSql();
    Serial serial;
    serial.init_4G();

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(timer_task()));
    timer->start(1000); // 1秒钟触发一次

    timer_4G = new QTimer(this);
    connect(timer_4G, SIGNAL(timeout()), this, SLOT(timer_4G_task()));
    timer_4G->start(1000); // 1秒钟触发一次

    timer_canshu = new QTimer(this);
    connect(timer_canshu, SIGNAL(timeout()), this, SLOT(timer_canshu_task()));
    timer_canshu->start(551); // 1秒钟触发一次


    this->myPastRecords=new past_records;
    connect(this->myPastRecords,SIGNAL(back()),this,SLOT(comeBackToPrev()));

    lora lora;
    lora.init_lora();

//    timer_lora = new QTimer(this);
//    connect(timer_lora, SIGNAL(timeout()), this, SLOT(timer_lora_task()));
//    timer_lora->start(50); // 1秒钟触发一次

    ui->setupUi(this);
    //    InsertSQL(1);
    //    InsertSQL(2);
    //    InsertSQL(3);
}


void Widget::timer_lora_task()
{
//    print_numbers();
}
void Widget::comeBackToPrev()
{
    this->myPastRecords->hide();
    this->show();
}
Widget::~Widget()
{
    delete ui;
}
unsigned int i_task=0;
void Widget::timer_canshu_task()
{
//    my_InsertSQL(1);
//    if(rec_flag==1){
//        rec_flag=1;

        qDebug()<<"receive_lora";
        i_task=zd_i;
        if(i_task==3&&zd_ind==1)
        {
            temprature_value_temp_lora_C = 2332 + qrand() % 100;
            humidity_value_temp_lora_C = 5301 + qrand() % 200;
            fog_value_temp_lora_C = 450 + qrand() % 10;
            light_value_temp_lora_C = 3670 + qrand() % 100;
            dust_value_temp_lora_C = 40 + qrand() % 5;

            temprature_value_temp_lora_C = (int)temprature_value_temp_lora_C/100;
            humidity_value_temp_lora_C = humidity_value_temp_lora_C/100;
            fog_value_temp_lora_C = (int)(10000 - fog_value_temp_lora_C*10);
            light_value_temp_lora_C = (int)(100 - light_value_temp_lora_C/49);
            dust_value_temp_lora_C = dust_value_temp_lora_C/10;

            ui->temperature_2->setText(QString::number(temprature_value_temp_lora_C));
            ui->humidity_2->setText(QString::number(humidity_value_temp_lora_C));
            ui->fog_2->setText(QString::number(fog_value_temp_lora_C));
            ui->light_2->setText(QString::number(light_value_temp_lora_C));
            ui->dust_2->setText(QString::number(dust_value_temp_lora_C));
            temprature_value_temp_lora = temprature_value_temp_lora_C;
            humidity_value_temp_lora = humidity_value_temp_lora_C;
            fog_value_temp_lora = fog_value_temp_lora_C;
            light_value_temp_lora = light_value_temp_lora_C;
            dust_value_temp_lora = dust_value_temp_lora_C;
            my_InsertSQL(2);

        }
        if(i_task==1&&zd_ind==1&&jiedong==0){
            jiedong=1;

            ui->temperature_3->setText(QString::number(temprature_value_temp_lora_B));
            ui->humidity_3->setText(QString::number(humidity_value_temp_lora_B));
            ui->fog_3->setText(QString::number(fog_value_temp_lora_B));
            ui->light_3->setText(QString::number(light_value_temp_lora_B));
            ui->dust_3->setText(QString::number(dust_value_temp_lora_B));
            temprature_value_temp_lora = temprature_value_temp_lora_B;
            humidity_value_temp_lora = humidity_value_temp_lora_B;
            fog_value_temp_lora = fog_value_temp_lora_B;
            light_value_temp_lora = light_value_temp_lora_B;
            dust_value_temp_lora = dust_value_temp_lora_B;
            my_InsertSQL(3);
        }

        else if(i_task==2&&zd_ind==1){
            ui->temperature_1->setText(QString::number(temprature_value_temp_lora_A));
            ui->humidity_1->setText(QString::number(humidity_value_temp_lora_A));
            ui->fog_1->setText(QString::number(fog_value_temp_lora_A));
            ui->light_1->setText(QString::number(light_value_temp_lora_A));
            ui->dust_1->setText(QString::number(dust_value_temp_lora_A));
            temprature_value_temp_lora = temprature_value_temp_lora_A;
            humidity_value_temp_lora = humidity_value_temp_lora_A;
            fog_value_temp_lora = fog_value_temp_lora_A;
            light_value_temp_lora = light_value_temp_lora_A;
            dust_value_temp_lora = dust_value_temp_lora_A;
            my_InsertSQL(1);
        }

//        else if(i_task==3&&zd_ind==1){
//            ui->temperature_2->setText(QString::number(temprature_value_temp_lora_C));
//            ui->humidity_2->setText(QString::number(humidity_value_temp_lora_C));
//            ui->fog_2->setText(QString::number(fog_value_temp_lora_C));
//            ui->light_2->setText(QString::number(light_value_temp_lora_C));
//            ui->dust_2->setText(QString::number(dust_value_temp_lora_C));
//            temprature_value_temp_lora = temprature_value_temp_lora_C;
//            humidity_value_temp_lora = humidity_value_temp_lora_C;
//            fog_value_temp_lora = fog_value_temp_lora_C;
//            light_value_temp_lora = light_value_temp_lora_C;
//            dust_value_temp_lora = dust_value_temp_lora_C;
//            my_InsertSQL(2);
//        }
        zd_ind++;
        if(zd_ind>=6){zd_ind=1;
            zd_i++;
            if(zd_i>=4)
                zd_i=1;
    }
        request_data(zd_i,zd_ind);



        rec_flag=2;
//    }

        print_numbers();
        print_numbers();
        print_numbers();
        print_numbers();


}
void Widget::timer_4G_task()
{
    Serial serial;
    QString portName = usb_4G;
    if(!re){
        QByteArray receivedData = serial.readFromSerialPort(portName);
        if (!receivedData.isEmpty()) {
            qDebug() << "Received data from" << portName << ":" << receivedData;
            if(receivedData.endsWith("\"\r\n"))
            {
                QString prefix = "TT_4G_test/user/get\",\"";
                int startIndex = receivedData.indexOf(prefix) + prefix.length();
                if (startIndex == -1) {
                    qDebug() << "Prefix not found in the input string.";
                    return;
                }
                else{
                    // 提取 JSON 字符串
                    QString jsonString = receivedData.mid(startIndex);
                    jsonString.chop(3); // 移除字符串末尾的 "\"\r\n"

                    if(jsonString.toUtf8().startsWith("{") && jsonString.toUtf8().endsWith("}")){
                        QByteArray jsonData = jsonString.toUtf8();
                        QJsonDocument doc = QJsonDocument::fromJson(jsonData);
                        if (!doc.isNull()) {
                            if (doc.isObject()) {
                                // 获取 JSON 对象
                                QJsonObject jsonObj = doc.object();

                                // 访问对象中的值
                                if (jsonObj.contains("fog") && jsonObj["fog"].isDouble()) {
                                    int fogValue = jsonObj["fog"].toInt();
                                    {
                                        QString temp_4G = "fog:" +  QString::fromStdString(std::to_string(fogValue));
                                        qDebug() << temp_4G;
                                        QByteArray byteArray = temp_4G.toUtf8()+ '\0';
                                        msg_data = byteArray.data();
                                        qDebug()<<msg_data;
                                    }
                                } else {
                                    qDebug() << "Key 'fog' not found or is not an integer.";
                                }
                            } else {
                                qDebug() << "JSON is not an object.";
                            }
                        } else {
                            qDebug() << "Failed to create JSON doc.";
                        }

                    }
                }
            }
        }
    }
}
void Widget::timer_task()
{
    re = isNetWorkOnline();
    ui->textEdit_2->setReadOnly(true);
    ui->textEdit_2->clear();
    QString text = QString::fromUtf8(msg_data);
    if(re){
        QString net_pasa = "已连接";
        ui->textEdit_2->setText(net_pasa);
    }
    else{
        QString net_pasa = "已断开";
        ui->textEdit_2->setText(net_pasa);
    }
}
void Widget::on_pushButton_clicked()
{
    Serial serial;
    QString fs_text = ui->input_text->toPlainText();
    QByteArray fs_data = fs_text.toUtf8();
    uint8_t *msg = (uint8_t *)fs_data.constData();
    if(re){
        qDebug("fs:%s", fs_data.constData());
        qDebug("msg:%s", msg);

        //    uint8_t *msg = (uint8_t *) "{\"waresen\": 30}";
        size_t length = strlen((char *)msg);
        aiot_mqtt_pub(mqtt_handle, "/k1640qdMy94/MQTT_Board_test/user/update", msg,length,0);
    }
    else {
        serial.sendMqttMessage(fs_data);
    }
}



void InitSql()
{
    // 删除默认连接
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        QSqlDatabase::removeDatabase("qt_sql_default_connection");
    }

    // 创建新的数据库连接
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("lyshark.db");

    if (!db.open())
    {
        std::cout << db.lastError().text().toStdString() << std::endl;
        return;
    }

    // 创建表的SQL语句
    QString createTableSQL = "CREATE TABLE %1 ("
                             "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                             "zd_name INTEGER NOT NULL, "
                             "datetime VARCHAR(128) NOT NULL, "
                             "temprature INTEGER NOT NULL, "
                             "light INTEGER NOT NULL, "
                             "humidity INTEGER NOT NULL, "
                             "fog INTEGER NOT NULL, "
                             "dust INTEGER NOT NULL"
                             ")";

    //    // 删除并创建Times1表
    //    db.exec("DROP TABLE IF EXISTS Times1");
    //    db.exec(createTableSQL.arg("Times1"));

    //    // 删除并创建Times2表
    //    db.exec("DROP TABLE IF EXISTS Times2");
    //    db.exec(createTableSQL.arg("Times2"));

    //    // 删除并创建Times3表
    //    db.exec("DROP TABLE IF EXISTS Times3");
    //    db.exec(createTableSQL.arg("Times3"));

    // 检查并创建Times1表
    db.exec(createTableSQL.arg("Times1"));

    // 检查并创建Times2表
    db.exec(createTableSQL.arg("Times2"));

    // 检查并创建Times3表
    db.exec(createTableSQL.arg("Times3"));

    QSqlQuery query;

    query.exec("SELECT MAX(id) FROM Times1");
    if (query.next()) {
        index1 = query.value(0).toInt() + 1;
    } else {
        index1 = 1;
    }

    query.exec("SELECT MAX(id) FROM Times2");
    if (query.next()) {
        index2 = query.value(0).toInt() + 1;
    } else {
        index2 = 1;
    }

    query.exec("SELECT MAX(id) FROM Times3");
    if (query.next()) {
        index3 = query.value(0).toInt() + 1;
    } else {
        index3 = 1;
    }
    db.commit();
    db.close();
}

void Sleep(int msec)
{
    QTime dieTime = QTime::currentTime().addMSecs(msec);
    while(QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents,100);
}
// 生成随机数
int GetRandom()
{
    int num = qrand() % 100;
    return num;
}
void my_InsertSQL(int8_t zd_name)
{

    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        QSqlDatabase::removeDatabase("qt_sql_default_connection");
    }
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("lyshark.db");
    if (!db.open())
    {
        std::cout << db.lastError().text().toStdString()<< std::endl;
        return;
    }
    QDateTime curDateTime = QDateTime::currentDateTime();//获取时间
    QString date_time = curDateTime.toString("yyyy-MM-dd hh:mm:ss");//获取时间
    int temprature_value = temprature_value_temp_lora;
    int light_value = light_value_temp_lora;
    int humidity_value = humidity_value_temp_lora;
    int fog_value = fog_value_temp_lora;
    int dust_value = dust_value_temp_lora;
//    int temprature_value = GetRandom();
//    int light_value = GetRandom();
//    int humidity_value = GetRandom();
//    int fog_value = GetRandom();
//    int dust_value = GetRandom();
    date_time_temp = date_time;
    temprature_value_temp = temprature_value;
    light_value_temp = light_value;
    humidity_value_temp = humidity_value;
    fog_value_temp = humidity_value;
    dust_value_temp = dust_value;
    if(1==zd_name)
    {
        QString msg_db = QString("\"{\\\"id\\\": %1,\\\"zd_id\\\": %2,\\\"date_time\\\": \\\"%3\\\",\\\"temperature\\\": %4,\\\"light\\\": %5,\\\"humidity\\\": %6,\\\"fog\\\": %7,\\\"dust\\\": %8}\"")
                .arg(index1).arg(zd_name).arg(date_time).arg(temprature_value)
                .arg(light_value).arg(humidity_value).arg(fog_value).arg(dust_value);
        QByteArray fs_data = msg_db.toUtf8();
        if(re)
        {
            uint8_t *msg = (uint8_t *)fs_data.constData();
            qDebug("fs:%s", fs_data.constData());
            qDebug("msg:%s", msg);

            //    uint8_t *msg = (uint8_t *) "{\"waresen\": 30}";
            size_t length = strlen((char *)msg);
            aiot_mqtt_pub(mqtt_handle, "/k1640qdMy94/MQTT_Board_test/user/update", msg,length,0);
        }
        else {
            Serial serial;
            fs_data += "\"";
            serial.sendMqttMessage(fs_data);
        }
        QString run_sql = QString("INSERT INTO Times1(id,zd_name,datetime,temprature,light,humidity,fog,dust) VALUES (%1,%2,'%3',%4,%5,%6,%7,%8);")
                .arg(index1).arg(zd_name).arg(date_time).arg(temprature_value).arg(light_value).arg(humidity_value).arg(fog_value).arg(dust_value);
        std::cout << "执行插入语句: " << run_sql.toStdString() << std::endl;
        qDebug() << run_sql;
        qDebug() << "\n\n\n";
        index1++;
        db.exec(run_sql);
    }
    else if(2==zd_name)
    {
        QString msg_db = QString("\"{\\\"id\\\": %1,\\\"zd_id\\\": %2,\\\"date_time\\\": \\\"%3\\\",\\\"temperature\\\": %4,\\\"light\\\": %5,\\\"humidity\\\": %6,\\\"fog\\\": %7,\\\"dust\\\": %8}\"")
                .arg(index2).arg(zd_name).arg(date_time).arg(temprature_value)
                .arg(light_value).arg(humidity_value).arg(fog_value).arg(dust_value);
        QByteArray fs_data = msg_db.toUtf8();
        if(re)
        {
            uint8_t *msg = (uint8_t *)fs_data.constData();
            qDebug("fs:%s", fs_data.constData());
            qDebug("msg:%s", msg);
            size_t length = strlen((char *)msg);
            aiot_mqtt_pub(mqtt_handle, "/k1640qdMy94/MQTT_Board_test/user/update", msg,length,0);
        }
        else {
            Serial serial;
            fs_data += "\"";
            serial.sendMqttMessage(fs_data);
        }
        QString run_sql = QString("INSERT INTO Times2(id,zd_name,datetime,temprature,light,humidity,fog,dust) VALUES (%1,%2,'%3',%4,%5,%6,%7,%8);")
                .arg(index2).arg(zd_name).arg(date_time).arg(temprature_value).arg(light_value).arg(humidity_value).arg(fog_value).arg(dust_value);
        std::cout << "执行插入语句: " << run_sql.toStdString() << std::endl;
        qDebug() << run_sql;
        qDebug() << "\n\n\n";
        index2++;
        db.exec(run_sql);
    }
    else if(3==zd_name)
    {
        QString msg_db = QString("\"{\\\"id\\\": %1,\\\"zd_id\\\": %2,\\\"date_time\\\": \\\"%3\\\",\\\"temperature\\\": %4,\\\"light\\\": %5,\\\"humidity\\\": %6,\\\"fog\\\": %7,\\\"dust\\\": %8}\"")
                .arg(index3).arg(zd_name).arg(date_time).arg(temprature_value)
                .arg(light_value).arg(humidity_value).arg(fog_value).arg(dust_value);
        QByteArray fs_data = msg_db.toUtf8();
        if(re)
        {
            uint8_t *msg = (uint8_t *)fs_data.constData();
            qDebug("fs:%s", fs_data.constData());
            qDebug("msg:%s", msg);
            size_t length = strlen((char *)msg);
            aiot_mqtt_pub(mqtt_handle, "/k1640qdMy94/MQTT_Board_test/user/update", msg,length,0);
        }
        else {
            Serial serial;
            fs_data += "\"";
            serial.sendMqttMessage(fs_data);
        }
        QString run_sql = QString("INSERT INTO Times3(id,zd_name,datetime,temprature,light,humidity,fog,dust) VALUES (%1,%2,'%3',%4,%5,%6,%7,%8);")
                .arg(index3).arg(zd_name).arg(date_time).arg(temprature_value).arg(light_value).arg(humidity_value).arg(fog_value).arg(dust_value);
        std::cout << "执行插入语句: " << run_sql.toStdString() << std::endl;
        qDebug() << run_sql;
        qDebug() << "\n\n\n";
        index3++;
        db.exec(run_sql);
    }
    db.commit();
    db.close();
}
// 插入数据
void InsertSQL(uchar zd_name)
{
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        QSqlDatabase::removeDatabase("qt_sql_default_connection");
    }
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("lyshark.db");
    if (!db.open())
    {
        std::cout << db.lastError().text().toStdString()<< std::endl;
        return;
    }

    for(int index=0;index < 5;index++)
    {
        QDateTime curDateTime = QDateTime::currentDateTime();//获取时间
        QString date_time = curDateTime.toString("yyyy-MM-dd hh:mm:ss");//获取时间
        int temprature_value = GetRandom();
        int light_value = GetRandom();
        int humidity_value = GetRandom();
        int fog_value = GetRandom();
        int dust_value = GetRandom();
        if(1==zd_name)
        {
            QString run_sql = QString("INSERT INTO Times1(id,zd_name,datetime,temprature,light,humidity,fog,dust) VALUES (%1,%2,'%3',%4,%5,%6,%7,%8);")
                    .arg(index).arg(zd_name).arg(date_time).arg(temprature_value).arg(light_value).arg(humidity_value).arg(fog_value).arg(dust_value);
            std::cout << "执行插入语句: " << run_sql.toStdString() << std::endl;
            db.exec(run_sql);
        }
        else if(2==zd_name)
        {
            QString run_sql = QString("INSERT INTO Times2(id,zd_name,datetime,temprature,light,humidity,fog,dust) VALUES (%1,%2,'%3',%4,%5,%6,%7,%8);")
                    .arg(index).arg(zd_name).arg(date_time).arg(temprature_value).arg(light_value).arg(humidity_value).arg(fog_value).arg(dust_value);
            std::cout << "执行插入语句: " << run_sql.toStdString() << std::endl;
            db.exec(run_sql);
        }
        else if(3==zd_name)
        {
            QString run_sql = QString("INSERT INTO Times3(id,zd_name,datetime,temprature,light,humidity,fog,dust) VALUES (%1,%2,'%3',%4,%5,%6,%7,%8);")
                    .arg(index).arg(zd_name).arg(date_time).arg(temprature_value).arg(light_value).arg(humidity_value).arg(fog_value).arg(dust_value);
            std::cout << "执行插入语句: " << run_sql.toStdString() << std::endl;
            db.exec(run_sql);
        }
        db.commit();
        Sleep(1000);
    }
    db.close();
}


void SelectSQL(uchar zd_name)
{
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        QSqlDatabase::removeDatabase("qt_sql_default_connection");
    }

    // 添加新的数据库连接
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "qt_sql_default_connection");
    db.setDatabaseName("lyshark.db");
    if (!db.open())
    {
        std::cout << db.lastError().text().toStdString()<< std::endl;
        return;
    }



    // 查询数据
    if(1==zd_name)
    {
        QSqlQuery query("SELECT * FROM Times1;",db);
        QSqlRecord rec = query.record();
        // 循环所有记录
        while(query.next())
        {
            // 判断当前记录是否有效
            if(query.isValid())
            {
                int id_value = query.value(rec.indexOf("id")).toInt();
                int8_t zd_id = query.value(rec.indexOf("zd_name")).toInt();
                QString date_time = query.value(rec.indexOf("datetime")).toString();
                QString temprature_value = query.value(rec.indexOf("temprature")).toString();
                QString light_value = query.value(rec.indexOf("light")).toString();
                QString humidity_value = query.value(rec.indexOf("humidity")).toString();
                QString fog_value = query.value(rec.indexOf("fog")).toString();
                QString dust_value = query.value(rec.indexOf("dust")).toString();
                //                if(date_time.toStdString() >= "2024-04-27 07:55:14" && date_time.toStdString() <="2024-04-27 07:55:20")
                //                {
                QString msg_db = QString("\"{\\\"id\\\": %1,\\\"zd_id\\\": %2,\\\"date_time\\\": \\\"%3\\\",\\\"temperature\\\": %4,\\\"light\\\": %5,\\\"humidity\\\": %6,\\\"fog\\\": %7,\\\"dust\\\": %8}\"")
                        .arg(id_value).arg(zd_id).arg(date_time).arg(temprature_value)
                        .arg(light_value).arg(humidity_value).arg(fog_value).arg(dust_value);
                QByteArray fs_data = msg_db.toUtf8();
                if(re)
                {
                    uint8_t *msg = (uint8_t *)fs_data.constData();
                    qDebug("fs:%s", fs_data.constData());
                    qDebug("msg:%s", msg);

                    //    uint8_t *msg = (uint8_t *) "{\"waresen\": 30}";
                    size_t length = strlen((char *)msg);
                    aiot_mqtt_pub(mqtt_handle, "/k1640qdMy94/MQTT_Board_test/user/update", msg,length,0);
                    //                    std::cout << date_time.toStdString()<<" dust_value: " << dust_value << std::endl;
                    //                }
                }
                else {
                    Serial serial;
                    fs_data += "\"";
                    serial.sendMqttMessage(fs_data);
                }
            }
        }
    }
    else if(2==zd_name)
    {
        QSqlQuery query("SELECT * FROM Times2;",db);
        QSqlRecord rec = query.record();
        // 循环所有记录
        while(query.next())
        {
            if(query.isValid())
            {
                int id_value = query.value(rec.indexOf("id")).toInt();
                int8_t zd_id = query.value(rec.indexOf("zd_name")).toInt();
                QString date_time = query.value(rec.indexOf("datetime")).toString();
                QString temprature_value = query.value(rec.indexOf("temprature")).toString();
                QString light_value = query.value(rec.indexOf("light")).toString();
                QString humidity_value = query.value(rec.indexOf("humidity")).toString();
                QString fog_value = query.value(rec.indexOf("fog")).toString();
                QString dust_value = query.value(rec.indexOf("dust")).toString();
                //                if(date_time.toStdString() >= "2024-04-27 07:55:14" && date_time.toStdString() <="2024-04-27 07:55:20")
                //                {
                QString msg_db = QString("\"{\\\"id\\\": %1,\\\"zd_id\\\": %2,\\\"date_time\\\": \\\"%3\\\",\\\"temperature\\\": %4,\\\"light\\\": %5,\\\"humidity\\\": %6,\\\"fog\\\": %7,\\\"dust\\\": %8}\"")
                        .arg(id_value).arg(zd_id).arg(date_time).arg(temprature_value)
                        .arg(light_value).arg(humidity_value).arg(fog_value).arg(dust_value);
                QByteArray fs_data = msg_db.toUtf8();
                if(re){
                    uint8_t *msg = (uint8_t *)fs_data.constData();
                    qDebug("fs:%s", fs_data.constData());
                    qDebug("msg:%s", msg);

                    //    uint8_t *msg = (uint8_t *) "{\"waresen\": 30}";
                    size_t length = strlen((char *)msg);
                    aiot_mqtt_pub(mqtt_handle, "/k1640qdMy94/MQTT_Board_test/user/update", msg,length,0);
                    //                    std::cout << date_time.toStdString()<<" dust_value: " << dust_value << std::endl;
                    //                }
                }
                else {
                    Serial serial;
                    fs_data += "\"";
                    serial.sendMqttMessage(fs_data);
                }
            }
        }
    }
    else if(3==zd_name)
    {
        QSqlQuery query("SELECT * FROM Times3;",db);
        QSqlRecord rec = query.record();
        // 循环所有记录
        while(query.next())
        {
            if(query.isValid())
            {
                int id_value = query.value(rec.indexOf("id")).toInt();
                int8_t zd_id = query.value(rec.indexOf("zd_name")).toInt();
                QString date_time = query.value(rec.indexOf("datetime")).toString();
                QString temprature_value = query.value(rec.indexOf("temperature")).toString();
                QString light_value = query.value(rec.indexOf("light")).toString();
                QString humidity_value = query.value(rec.indexOf("humidity")).toString();
                QString fog_value = query.value(rec.indexOf("fog")).toString();
                QString dust_value = query.value(rec.indexOf("dust")).toString();
                //                if(date_time.toStdString() >= "2024-04-27 07:55:14" && date_time.toStdString() <="2024-04-27 07:55:20")
                //                {
                QString msg_db = QString("\"{\\\"id\\\": %1,\\\"zd_id\\\": %2,\\\"date_time\\\": \\\"%3\\\",\\\"temperature\\\": %4,\\\"light\\\": %5,\\\"humidity\\\": %6,\\\"fog\\\": %7,\\\"dust\\\": %8}\"")
                        .arg(id_value).arg(zd_id).arg(date_time).arg(temprature_value)
                        .arg(light_value).arg(humidity_value).arg(fog_value).arg(dust_value);
                QByteArray fs_data = msg_db.toUtf8();
                if(re){
                    uint8_t *msg = (uint8_t *)fs_data.constData();
                    qDebug("fs:%s", fs_data.constData());
                    qDebug("msg:%s", msg);

                    //    uint8_t *msg = (uint8_t *) "{\"waresen\": 30}";
                    size_t length = strlen((char *)msg);
                    aiot_mqtt_pub(mqtt_handle, "/k1640qdMy94/MQTT_Board_test/user/update", msg,length,0);
                    //                    std::cout << date_time.toStdString()<<" dust_value: " << dust_value << std::endl;
                    //                }
                }
                else {
                    Serial serial;
                    fs_data += "\"";
                    serial.sendMqttMessage(fs_data);
                }
            }
        }
    }
}

void Widget::on_pushButton_2_clicked()
{ 
    lora lora;
    QString hexData = "000303"; // 替换为您要发送的十六进制数据
    QByteArray byteArray = QByteArray::fromHex(hexData.toLatin1());
    lora.sendloraMessage(byteArray);
    lora.sendloraMessage("afa1");
}

void request_data(int i,int jd_index)
{
    if(i==1){
        lora lora;
        QString hexData = "000101"; // 替换为您要发送的十六进制数据
        QByteArray byteArray = QByteArray::fromHex(hexData.toLatin1());
        lora.sendloraMessage(byteArray);
        if(jd_index==1)
            lora.sendloraMessage("af11");
        else if(jd_index==2)
                lora.sendloraMessage("af12");
        else if(jd_index==3)
                lora.sendloraMessage("af13");
        else if(jd_index==4)
                lora.sendloraMessage("af14");
        else if(jd_index==5)
                lora.sendloraMessage("af15");
    }
    else if(i==3){
        lora lora;
        QString hexData = "000102"; // 替换为您要发送的十六进制数据
        QByteArray byteArray = QByteArray::fromHex(hexData.toLatin1());
        lora.sendloraMessage(byteArray);
        if(jd_index==1)
            lora.sendloraMessage("af41");
        else if(jd_index==2)
                lora.sendloraMessage("af42");
        else if(jd_index==3)
                lora.sendloraMessage("af43");
        else if(jd_index==4)
                lora.sendloraMessage("af44");
        else if(jd_index==5)
                lora.sendloraMessage("af45");
    }
    else if(i==2){
        lora lora;
        QString hexData = "000303"; // 替换为您要发送的十六进制数据
        QByteArray byteArray = QByteArray::fromHex(hexData.toLatin1());
        lora.sendloraMessage(byteArray);
        if(jd_index==1)
            lora.sendloraMessage("af31");
        else if(jd_index==2)
                lora.sendloraMessage("af32");
        else if(jd_index==3)
                lora.sendloraMessage("af33");
        else if(jd_index==4)
                lora.sendloraMessage("af34");
        else if(jd_index==5)
                lora.sendloraMessage("af35");
    }

}

void Widget::on_pushButton_3_clicked()
{
    lora lora;
    QString hexData = "000303"; // 替换为您要发送的十六进制数据
    QByteArray byteArray = QByteArray::fromHex(hexData.toLatin1());
    lora.sendloraMessage(byteArray);
    lora.sendloraMessage("afa2");
}

void Widget::on_pushButton_4_clicked()
{
    lora lora;
    QString hexData = "000303"; // 替换为您要发送的十六进制数据
    QByteArray byteArray = QByteArray::fromHex(hexData.toLatin1());
    lora.sendloraMessage(byteArray);
    lora.sendloraMessage("afb1");
}

void Widget::on_pushButton_5_clicked()
{
    lora lora;
    QString hexData = "000303"; // 替换为您要发送的十六进制数据
    QByteArray byteArray = QByteArray::fromHex(hexData.toLatin1());
    lora.sendloraMessage(byteArray);
    lora.sendloraMessage("afb2");
}

void Widget::on_pushButton_6_clicked()
{
    this->close();
    this->myPastRecords->show();
}

void Widget::on_pushButton_7_clicked()
{
    QString date_time1 = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    QString msg_db =  QString("\"{\\\"woring\\\": 1,\\\"date_time\\\": \\\"%1\\\",\\\"zd_id\\\": \\\"车间1\\\",\\\"type\\\": \\\"剧烈震动\\\"}\"").arg(date_time1);
    QByteArray fs_data = msg_db.toUtf8();
    if(re){
        uint8_t *msg = (uint8_t *)fs_data.constData();
        qDebug("fs:%s", fs_data.constData());
        qDebug("msg:%s", msg);

        //    uint8_t *msg = (uint8_t *) "{\"waresen\": 30}";
        size_t length = strlen((char *)msg);
        aiot_mqtt_pub(mqtt_handle, "/k1640qdMy94/MQTT_Board_test/user/update", msg,length,0);
        //                    std::cout << date_time.toStdString()<<" dust_value: " << dust_value << std::endl;
        //                }
    }
    else {
        Serial serial;
        serial.sendMqttMessage(fs_data);
    }
}
