#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QCoreApplication>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlRecord>
#include <iostream>
#include <QStringList>
#include <QString>
#include <QVariant>
#include <QDebug>
#include <QDateTime>
#include <QTime>
#include <QTimer>
#include <QDebug>
#include <QNetworkConfigurationManager>
#include "serial.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <past_records.h>

void InitSql();
void my_InsertSQL(int8_t zd_name);
void InsertSQL(uchar zd_name);
void SelectSQL(uchar zd_name);
int GetRandom();
namespace Ui {
class Widget;
}
class past_records;
class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

    past_records *myPastRecords=NULL;
private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();
    void timer_task();
    void timer_4G_task();
    void timer_lora_task();
    void timer_canshu_task();
    void comeBackToPrev();
    bool isNetWorkOnline()
    {
        QNetworkConfigurationManager mgr;
        return mgr.isOnline();
    }
    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

private:
    Ui::Widget *ui;
    QTimer *timer;
    QTimer *timer_4G;
    QTimer *timer_canshu;
    QTimer *timer_lora;
};

#endif // WIDGET_H
