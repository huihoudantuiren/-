#include "QDebug"
#include "QPushButton"
#include "serial.h"

Serial::Serial() {
    // Initialize the serial port or other members as needed
}

Serial::~Serial() {
    if (serial.isOpen())
        serial.close();
}

bool Serial::writeToSerialPort(const QString &portName, const QByteArray &message) {
    QSerialPort serial;
    serial.setPortName(portName);
    serial.setBaudRate(QSerialPort::Baud9600); // 设置波特率，根据需求调整
    serial.setDataBits(QSerialPort::Data8);      // 设置数据位
    serial.setParity(QSerialPort::NoParity);     // 设置校验位
    serial.setStopBits(QSerialPort::OneStop);    // 设置停止位
    serial.setFlowControl(QSerialPort::NoFlowControl); // 设置流控制

    if (!serial.open(QIODevice::ReadWrite)) {
        qDebug() << "Failed to open port" << portName << ", error:" << serial.errorString();
        return false;
    }

    if (serial.write(message) == -1) {
        qDebug() << "Failed to write data to port" << portName << ", error:" << serial.errorString();
        serial.close();
        return false;
    }

    serial.flush(); // 确保数据完全写入
    serial.close();
    return true;
}

QByteArray Serial::readFromSerialPort(const QString &portName) {
    QSerialPort serial;
    serial.setPortName(portName);
    serial.setBaudRate(QSerialPort::Baud9600); // 根据需要设置波特率
    serial.setDataBits(QSerialPort::Data8);
    serial.setParity(QSerialPort::NoParity);
    serial.setStopBits(QSerialPort::OneStop);
    serial.setFlowControl(QSerialPort::NoFlowControl);

    if (!serial.open(QIODevice::ReadOnly)) {
        qDebug() << "Failed to open port" << portName << ", error:" << serial.errorString();
        return QByteArray();
    }

    QByteArray readData;
    if (serial.waitForReadyRead(100)) { // 等待最多100毫秒
        readData = serial.readAll();
        while (serial.waitForReadyRead(100)) // 继续等待100毫秒，直到没有更多数据
            readData.append(serial.readAll());
    }

    serial.close();
    return readData;
}
void Serial::sendMqttMessage(const QByteArray &message)
{
    QString portName = usb_4G;//串口地址
    Serial serial;
    QString dataToWrite =  QString("AT+QMTPUBEX=0,0,0,0,\"/k1640qdMy94/MQTT_4G_test/user/update\",%1\r\n").arg(message.size());
    if(serial.writeToSerialPort(portName, dataToWrite.toUtf8())) {
        qDebug() << "message written successfully to" << portName;
    } else {
        qDebug() << "Failed to write message to" << portName;
    }
    QByteArray receivedData = serial.readFromSerialPort(portName);
    if (!receivedData.isEmpty()) {
        qDebug() << "Received data from" << portName << ":" << receivedData;
    } else {
        qDebug() << "No data received from" << portName << "or read timeout.";
    }
    if(serial.writeToSerialPort(portName, message)) {
        qDebug() << "message2 written successfully to" << portName;
    } else {
        qDebug() << "Failed to write message2 to" << portName;
    }
    sleep(0.5);
}
void Serial::init_4G()
{
    QString portName = usb_4G;//串口地址
    Serial serial;
    serial.listPorts();

    QByteArray dataToWrite =
            "AT+QMTCLOSE=0\r\n";
    if (serial.writeToSerialPort(portName, dataToWrite)) {
        qDebug() << "断网 written successfully to" << portName;
    } else {
        qDebug() << "Failed to write 断网 to" << portName;
    }
    QByteArray receivedData = serial.readFromSerialPort(portName);
    if (!receivedData.isEmpty()) {
        qDebug() << "Received data from" << portName << ":" << receivedData;
    } else {
        qDebug() << "No data received from" << portName << "or read timeout.";
    }

    // 写入数据到串口1
    dataToWrite =
            "AT+QMTCFG=\"ALIAUTH\",0,\"k1640qdMy94\",\"MQTT_4G_test\",\"9ccae22b1c01d9e521d3060050779ba0\"\r\n";
    if (serial.writeToSerialPort(portName, dataToWrite)) {
        qDebug() << "Data1 written successfully to" << portName;
    } else {
        qDebug() << "Failed1 to write data to" << portName;
    }
    // 从串口读取数据1
    receivedData = serial.readFromSerialPort(portName);
    if (!receivedData.isEmpty()) {
        qDebug() << "Received data from" << portName << ":" << receivedData;
    } else {
        qDebug() << "No data received from" << portName << "or read timeout.";
    }
    // 写入数据到串口2,读取函数都会最多等待1s
    dataToWrite =
            "AT+QMTOPEN=0,\"k1640qdMy94.iot-as-mqtt.cn-shanghai.aliyuncs.com\",1883\r\n";
    if (serial.writeToSerialPort(portName, dataToWrite)) {
        qDebug() << "Data2 written successfully to" << portName;
    } else {
        qDebug() << "Failed2 to write data to" << portName;
    }

    // 从串口读取数据2,读取函数都会最多等待1s
    receivedData = serial.readFromSerialPort(portName);
    if (!receivedData.isEmpty()) {
        qDebug() << "Received data from" << portName << ":" << receivedData;
    } else {
        qDebug() << "No data received from" << portName << "or read timeout.";
    }
    // 写入数据到串口3
    sleep(1);
    dataToWrite =
            "AT+QMTCONN=0,\"CAT\"\r\n";
    if (serial.writeToSerialPort(portName, dataToWrite)) {
        qDebug() << "Data3 written successfully to" << portName;
    } else {
        qDebug() << "Failed3 to write data to" << portName;
    }

    // 从串口读取数据3,读取函数都会最多等待1s
    receivedData = serial.readFromSerialPort(portName);
    if (!receivedData.isEmpty()) {
        qDebug() << "Received data from" << portName << ":" << receivedData;
    } else {
        qDebug() << "No data received from" << portName << "or read timeout.";
    }
    sleep(1);
    // 写入数据到串口4
    dataToWrite =
            "AT+QMTSUB=0,1,\"/k1640qdMy94/MQTT_4G_test/user/get\",0\r\n";
    if (serial.writeToSerialPort(portName, dataToWrite)) {
        qDebug() << "Data4 written successfully to" << portName;
    } else {
        qDebug() << "Failed4 to write data to" << portName;
    }

    // 从串口读取数据4,读取函数都会最多等待1s
    receivedData = serial.readFromSerialPort(portName);
    if (!receivedData.isEmpty()) {
        qDebug() << "Received data from" << portName << ":" << receivedData;
    } else {
        qDebug() << "No data received from" << portName << "or read timeout.";
    }

}


//void Serial::send_and_rece_lora()
//{
//    QString portName = usb_lora;//串口地址
//    Serial serial;
//    serial.listPorts();

//    QByteArray dataToWrite =
//            "AT+QMTCLOSE=0\r\n";
//    if (serial.writeToSerialPort(portName, dataToWrite)) {
//        qDebug() << "断网 written successfully to" << portName;
//    } else {
//        qDebug() << "Failed to write 断网 to" << portName;
//    }
//    QByteArray receivedData = serial.readFromSerialPort(portName);
//    if (!receivedData.isEmpty()) {
//        qDebug() << "Received data from" << portName << ":" << receivedData;
//    } else {
//        qDebug() << "No data received from" << portName << "or read timeout.";
//    }

//    // 写入数据到串口1
//    dataToWrite =
//            "AT+QMTCFG=\"ALIAUTH\",0,\"k1640qdMy94\",\"MQTT_4G_test\",\"9ccae22b1c01d9e521d3060050779ba0\"\r\n";
//    if (serial.writeToSerialPort(portName, dataToWrite)) {
//        qDebug() << "Data1 written successfully to" << portName;
//    } else {
//        qDebug() << "Failed1 to write data to" << portName;
//    }
//    // 从串口读取数据1
//    receivedData = serial.readFromSerialPort(portName);
//    if (!receivedData.isEmpty()) {
//        qDebug() << "Received data from" << portName << ":" << receivedData;
//    } else {
//        qDebug() << "No data received from" << portName << "or read timeout.";
//    }
//    // 写入数据到串口2,读取函数都会最多等待1s
//    dataToWrite =
//            "AT+QMTOPEN=0,\"k1640qdMy94.iot-as-mqtt.cn-shanghai.aliyuncs.com\",1883\r\n";
//    if (serial.writeToSerialPort(portName, dataToWrite)) {
//        qDebug() << "Data2 written successfully to" << portName;
//    } else {
//        qDebug() << "Failed2 to write data to" << portName;
//    }

//    // 从串口读取数据2,读取函数都会最多等待1s
//    receivedData = serial.readFromSerialPort(portName);
//    if (!receivedData.isEmpty()) {
//        qDebug() << "Received data from" << portName << ":" << receivedData;
//    } else {
//        qDebug() << "No data received from" << portName << "or read timeout.";
//    }
//    // 写入数据到串口3
//    sleep(1);
//    dataToWrite =
//            "AT+QMTCONN=0,\"CAT\"\r\n";
//    if (serial.writeToSerialPort(portName, dataToWrite)) {
//        qDebug() << "Data3 written successfully to" << portName;
//    } else {
//        qDebug() << "Failed3 to write data to" << portName;
//    }

//    // 从串口读取数据3,读取函数都会最多等待1s
//    receivedData = serial.readFromSerialPort(portName);
//    if (!receivedData.isEmpty()) {
//        qDebug() << "Received data from" << portName << ":" << receivedData;
//    } else {
//        qDebug() << "No data received from" << portName << "or read timeout.";
//    }
//    sleep(1);
//    // 写入数据到串口4
//    dataToWrite =
//            "AT+QMTSUB=0,1,\"/k1640qdMy94/MQTT_4G_test/user/get\",0\r\n";
//    if (serial.writeToSerialPort(portName, dataToWrite)) {
//        qDebug() << "Data4 written successfully to" << portName;
//    } else {
//        qDebug() << "Failed4 to write data to" << portName;
//    }

//    // 从串口读取数据4,读取函数都会最多等待1s
//    receivedData = serial.readFromSerialPort(portName);
//    if (!receivedData.isEmpty()) {
//        qDebug() << "Received data from" << portName << ":" << receivedData;
//    } else {
//        qDebug() << "No data received from" << portName << "or read timeout.";
//    }

//}


void Serial::listPorts()
{
    QList<QSerialPortInfo> serialPortInfos = QSerialPortInfo::availablePorts();
    qDebug() << "Total numbers of ports: " << serialPortInfos.count();
    foreach (const QSerialPortInfo &portInfo, serialPortInfos) {
        qDebug() << "Port：" << portInfo.portName();
    }
}

QSerialPort* Serial::getSerialPort(const QString &portName) {
    if (serial.portName() == portName && serial.isOpen())
        return &serial;
    else
        return nullptr;  // In a complete implementation, you'd manage multiple ports here.
}
/*if(flag)
 {
     qDebug() << "open!!!!";
     //配置串口参数
     serial->setBaudRate(Serial::Baud9600);
     serial->setDataBits(Serial::Data8);
     serial->setParity(Serial::NoParity);
     serial->setStopBits(Serial::OneStop);
   //  connect(serial, SIGNAL(readyRead()), this, SLOT(read()));
     //connect(serial,&QSerialPort::readyRead, this, &Widget::read);
 }else
 {
     qDebug() << "not open";
 }
}*/

/*QString Serial::read(){
      qDebug() << "read start";
      while (serial->bytesAvailable()) {
          data = serial->readAll();
      }
      qDebug() <<i<< ":The received words are" << data;
      qDebug() << "read end";
      i++;
      QString strData(data); // 将 QByteArray 转换为 QString
      return strData;
}
*/


/*void Serial::temperature(QString &s){
    temperature1=0;
    temperature2=0;
    qDebug()<<s<<endl;
    if (s== "Device1:ready") {
                flag1 = 1;
      }else if(s== "Device2:ready"){
        flag2=1;
    }else if(s== "Device1:readyDevice2:ready"){
        flag1=flag2=1;
    }else{
           /* int index = 0;
            while (index < s.length()) {
                // 查找设备ID的起始位置
                int deviceIdIndex = s.indexOf("Device", index);
                if (deviceIdIndex == -1) {
                    // 未找到设备ID，忽略剩余部分
                    break;
                }
                // 提取设备ID
                QString deviceIdStr = s.mid(deviceIdIndex, 7); // 假设设备ID的长度为固定的7个字符
                QString deviceId = deviceIdStr.mid(6, 1); // 提取设备ID中的数字部分

                // 查找温度值的起始位置
                int temperatureIndex = s.indexOf(":", deviceIdIndex);
                if (temperatureIndex == -1) {
                    // 未找到温度值，忽略当前设备ID
                    index = deviceIdIndex + deviceIdStr.length();
                    continue;
                }

                // 查找温度值的结束位置
                int endIndex = s.indexOf("Device", temperatureIndex);
                if (endIndex == -1) {
                    // 未找到下一个设备ID，说明当前温度值是最后一个
                    endIndex = s.length();
                }
                // 提取温度值
                QString temperatureStr = s.mid(temperatureIndex + 1, endIndex - temperatureIndex - 1);
                bool ok;
                int temperature = temperatureStr.toInt(&ok);
                if (!ok) {
                    // 温度值解析失败，忽略当前设备ID
                    index = endIndex;
                    continue;
                }
                // 根据设备ID将温度值赋给相应的变量
                if (deviceId == "1") {
                    temperature1 = temperature;
                } else if (deviceId == "2") {
                    temperature2 = temperature;
                }
                // 更新索引位置，从当前设备ID的结束位置继续查找
                index = endIndex + 1;
            }*/
// 在初始化函数或构造函数中设置定时器
/*
            timer1.setInterval(5000);
            timer2.setInterval(5000);
            // 连接定时器的超时信号与槽函数
            connect(&timer1, &QTimer::timeout, this,  &Serial::onTimer1Timeout);
            connect(&timer2, &QTimer::timeout, this,  &Serial::onTimer2Timeout);
            // 启动定时器
            timer1.start();
            timer2.start();
        }
        // 分割消息，提取每个设备的数据
        QStringList dataList = s.split("Device", QString::SkipEmptyParts);
        for (const QString& deviceData : dataList) {
            QStringList deviceInfo = deviceData.split(":", QString::SkipEmptyParts);
            if (deviceInfo.length() == 2) {
                // 提取设备ID和温度值
                QString deviceId = deviceInfo[0].trimmed();
                QString temperatureStr = deviceInfo[1].trimmed();
                bool ok;
                int temperature = temperatureStr.toInt(&ok);
                if (ok) {
                    if (deviceId == "1") {
                        // 收到设备1的消息，重置定时器
                        timer1.start();
                        flag1 = 1; // 标志位设为 1
                        temperature1 = temperature; // 更新温度值
                    } else if (deviceId == "2") {
                        // 收到设备2的消息，重置定时器
                        timer2.start();
                        flag2 = 1; // 标志位设为 1
                        temperature2 = temperature; // 更新温度值
                    }
                }
            }
        }

        qDebug()<<"temperature1:"<<temperature1;
        qDebug()<<"temperature2:"<<temperature2;
        qDebug()<<"flag1:"<<flag1;
        qDebug()<<"flag2:"<<flag2;
        }
        */
/*void Serial::onTimer1Timeout(){
    // 在设备1的定时器超时时将 flag1 置为 0
    flag1 = 0;
}
void Serial::onTimer2Timeout(){
    // 在设备2的定时器超时时将 flag2 置为 0
    flag2 = 0;
}
*/


/*void Serial::close(){
      serial->close();
      qDebug() << "serial close!";
  }
*/
