#include "past_records.h"
#include "ui_past_records.h"
#include "QDebug"
past_records::past_records(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::past_records)
{

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(timer_task()));
    timer->start(2000); // 1秒钟触发一次
    ui->setupUi(this);
    ui->dateTimeEdit->setDisplayFormat("yyyy-MM-dd HH:mm:ss");
    ui->dateTimeEdit_2->setDisplayFormat("yyyy-MM-dd HH:mm:ss");
    QDateTime current_date_time =QDateTime::currentDateTime();
    ui->dateTimeEdit->setDateTime(current_date_time);
    ui->dateTimeEdit_2->setDateTime(current_date_time);
    InitChart();
}

past_records::~past_records()
{
    delete ui;
}

void past_records::on_pushButton_clicked()
{
    emit this->back();
}
void past_records::InitChart()
{
    // 创建图表的各个部件
    QChart *chart = new QChart();

    // 将Chart添加到ChartView
    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    // 隐藏图例
    chart->legend()->hide();

    //    // 设置图表主题色
    //    ui->graphicsView->chart()->setTheme(QChart::ChartTheme(1));

    // 创建曲线序列
    QLineSeries *series0 = new QLineSeries();

    // 序列添加到图表
    chart->addSeries(series0);
    chart->setTheme(QChart::ChartThemeBlueCerulean);
    // 创建坐标轴
    QValueAxis *axisX = new QValueAxis;    // X轴
    axisX->setRange(1, 100);               // 设置坐标轴范围

    QValueAxis *axisY = new QValueAxis;    // Y轴
    axisY->setRange(0, 100);               // Y轴范围
    axisY->setMinorTickCount(4);           // s设置Y轴刻度

    // 设置X于Y轴数据集
    chart->setAxisX(axisX, series0);   // 为序列设置坐标轴
    chart->setAxisY(axisY, series0);
}
void past_records::plotArrayData(const QVector<QString>& datetimes, const QVector<int>& temperatures)
{
//    QString start_user_time = ui->dateTimeEdit_Start->toPlainText();
//    QString end_user_time = ui->dateTimeEdit_End->toPlainText();

//    QDateTime start_timet = QDateTime::fromString(start_user_time, "yyyy-MM-dd hh:mm:ss");
//    QDateTime end_timet = QDateTime::fromString(end_user_time, "yyyy-MM-dd hh:mm:ss");

    QDateTime start_timet = ui->dateTimeEdit->dateTime();
    QDateTime end_timet = ui->dateTimeEdit_2->dateTime();

    QString start_user_time = start_timet.toString("yyyy-MM-dd HH:mm:ss");
    QString end_user_time = end_timet.toString("yyyy-MM-dd HH:mm:ss");
    start_timet = QDateTime::fromString(start_user_time, "yyyy-MM-dd hh:mm:ss");
    end_timet = QDateTime::fromString(end_user_time, "yyyy-MM-dd hh:mm:ss");
    int flag=0;
    if(start_user_time!=""&&end_user_time!=""&&start_timet<end_timet)
        flag=1;
    if(flag){
        qDebug()<<start_user_time;
        qDebug()<<end_user_time;
        QChart *chart = new QChart();
        QLineSeries *series = new QLineSeries();
        qDebug()<<temperatures.size();

        QDateTime start_timet1 = QDateTime::fromString("2999-12-30 23:59:59", "yyyy-MM-dd hh:mm:ss");
        QDateTime end_timet1 = QDateTime::fromString("2000-1-1 1:1:0", "yyyy-MM-dd hh:mm:ss");

        for (int i = 0; i < temperatures.size(); ++i) {
            if(datetimes[i].toStdString() >= start_user_time.toStdString() && datetimes[i].toStdString() <= end_user_time.toStdString()){
                QDateTime datetime = QDateTime::fromString(datetimes[i], "yyyy-MM-dd HH:mm:ss");
                series->append(datetime.toMSecsSinceEpoch(), temperatures[i]);
                if(start_timet1>datetime){
                    start_timet1=datetime;
                }
                if(end_timet1<datetime){
                    end_timet1=datetime;
                }
            }
        }
        int span = start_timet1.secsTo(end_timet1); // 计算时间跨度，单位为秒
        chart->addSeries(series);
        chart->legend()->hide();
        // 创建并设置X轴为时间轴


        QDateTimeAxis *axisX = new QDateTimeAxis;
        if (span > 2 * 24 * 3600) { // 超过两天
            axisX->setFormat("MM-dd"); // 设置刻度为天
        } else if (span > 2 * 3600) { // 超过两小时
            axisX->setFormat("MM-dd HH"); // 设置刻度为小时
        } else if (span > 2 * 60) { // 超过两分钟
            axisX->setFormat("HH:mm"); // 设置刻度为分钟
        } else {
            axisX->setFormat("HH:mm:ss"); // 设置刻度为秒
        }
        axisX->setTitleText("时间");
        axisX->setLabelsAngle(-75);
        QFont font;
        font.setPointSize(10);
        axisX->setLabelsFont(font);
        int tickCount ;
        if(span<=2 * 60)   {
            tickCount=5;
        }
        else  if(span>=2 * 60){
            tickCount=7;
        }

        axisX->setTickCount(tickCount);
        chart->setAxisX(axisX, series);

        // 创建并设置Y轴（假设Y轴数据为整数）
        QValueAxis *axisY = new QValueAxis();
        axisY->setLabelFormat("%i");
        if(ui->comboBox->currentText()=="温度"){
            axisY->setTitleText("温度 (°C)");
            chart->setTitle("历史温度数据");
        }
        else if(ui->comboBox->currentText()=="湿度"){
            axisY->setTitleText("湿度 (%)");
            chart->setTitle("历史湿度数据");
        }
        else if(ui->comboBox->currentText()=="光强"){
            axisY->setTitleText("光强 (lx)");
            chart->setTitle("历史光强数据");
        }
        else if(ui->comboBox->currentText()==""){
            axisY->setTitleText("震动 (µg/m³)");
            chart->setTitle("历史震动数据");
        }
        else if(ui->comboBox->currentText()=="烟雾"){
            axisY->setTitleText("烟雾 (ppm)");
            chart->setTitle("历史烟雾数据");
        }
        axisY->applyNiceNumbers();
        chart->setAxisY(axisY, series);

        // 设置图表主题
        chart->setTheme(QChart::ChartThemeBlueCerulean);

        // 将图表设置到视图
        ui->graphicsView->setChart(chart);
        ui->graphicsView->setRenderHint(QPainter::Antialiasing); // 设置抗锯齿，以改善图形的视觉质量

    }
    else if(!flag){
        qDebug()<<start_user_time;
        qDebug()<<end_user_time;
        QChart *chart = new QChart();
        QLineSeries *series = new QLineSeries();
        qDebug()<<temperatures.size();

        QDateTime minDatetime = QDateTime::fromString(datetimes[0], "yyyy-MM-dd HH:mm:ss");
        QDateTime maxDatetime = QDateTime::fromString(datetimes[datetimes.size()-1], "yyyy-MM-dd HH:mm:ss");
        int span = minDatetime.secsTo(maxDatetime); // 计算时间跨度，单位为秒


        // 添加数据点到系列
//        for (int i = 0; i < temperatures.size(); ++i) {
//            QDateTime datetime = QDateTime::fromString(datetimes[i], "yyyy-MM-dd HH:mm:ss");
//            series->append(datetime.toMSecsSinceEpoch(), temperatures[i]);
//        }

        chart->addSeries(series);
        chart->legend()->hide();

        // 创建并设置X轴为时间轴


        QDateTimeAxis *axisX = new QDateTimeAxis;
        if (span > 2 * 24 * 3600) { // 超过两天
            axisX->setFormat("MM-dd"); // 设置刻度为天
        } else if (span > 2 * 3600) { // 超过两小时
            axisX->setFormat("MM-dd HH"); // 设置刻度为小时
        } else if (span > 2 * 60) { // 超过两分钟
            axisX->setFormat("HH:mm"); // 设置刻度为分钟
        } else {
            axisX->setFormat("HH:mm:ss"); // 设置刻度为秒
        }
        axisX->setTitleText("时间");
        axisX->setLabelsAngle(-75);
        QFont font;
        font.setPointSize(10);
        axisX->setLabelsFont(font);
        int tickCount ;
        if(temperatures.size()<=10)   {
            tickCount=5;
        }
        else  if(temperatures.size()>10&&temperatures.size()<=100){
            tickCount=7;
        }

//        axisX->setTickCount(tickCount);
//        chart->setAxisX(axisX, series);

        // 创建并设置Y轴（假设Y轴数据为整数）
        QValueAxis *axisY = new QValueAxis();
        axisY->setLabelFormat("%i");
        if(ui->comboBox->currentText()=="温度"){
            axisY->setTitleText("温度 (°C)");
            chart->setTitle("时间段设置错误");
        }
        else if(ui->comboBox->currentText()=="湿度"){
            axisY->setTitleText("湿度 (%)");
            chart->setTitle("时间段设置错误");
        }
        else if(ui->comboBox->currentText()=="光强"){
            axisY->setTitleText("光强 (lx)");
            chart->setTitle("时间段设置错误");
        }
        else if(ui->comboBox->currentText()=="震动"){
            axisY->setTitleText("震动 (µg/m³)");
            chart->setTitle("时间段设置错误");
        }
        else if(ui->comboBox->currentText()=="烟雾"){
            axisY->setTitleText("烟雾 (ppm)");
            chart->setTitle("时间段设置错误");
        }
//        axisY->applyNiceNumbers();
//        chart->setAxisY(axisY, series);

        // 设置图表主题
        chart->setTheme(QChart::ChartThemeBlueCerulean);

        // 将图表设置到视图
        ui->graphicsView->setChart(chart);
        ui->graphicsView->setRenderHint(QPainter::Antialiasing); // 设置抗锯齿，以改善图形的视觉质量
    }
}
void past_records::plotArrayData_sishi(const QVector<QString>& datetimes, const QVector<int>& temperatures)
{
    QChart *chart = new QChart();
    QLineSeries *series = new QLineSeries();
    qDebug()<<temperatures.size();

    QDateTime minDatetime = QDateTime::fromString(datetimes[0], "yyyy-MM-dd HH:mm:ss");
    QDateTime maxDatetime = QDateTime::fromString(datetimes[datetimes.size()-1], "yyyy-MM-dd HH:mm:ss");
    int span = minDatetime.secsTo(maxDatetime); // 计算时间跨度，单位为秒


    // 添加数据点到系列
    for (int i = 0; i < temperatures.size(); ++i) {
        QDateTime datetime = QDateTime::fromString(datetimes[i], "yyyy-MM-dd HH:mm:ss");
        series->append(datetime.toMSecsSinceEpoch(), temperatures[i]);
    }

    chart->addSeries(series);
    chart->legend()->hide();

    // 创建并设置X轴为时间轴


    QDateTimeAxis *axisX = new QDateTimeAxis;
    if (span > 2 * 24 * 3600) { // 超过两天
        axisX->setFormat("MM-dd"); // 设置刻度为天
    } else if (span > 2 * 3600) { // 超过两小时
        axisX->setFormat("MM-dd HH"); // 设置刻度为小时
    } else if (span > 2 * 60) { // 超过两分钟
        axisX->setFormat("HH:mm"); // 设置刻度为分钟
    } else {
        axisX->setFormat("HH:mm:ss"); // 设置刻度为秒
    }
    axisX->setTitleText("时间");
    axisX->setLabelsAngle(-75);
    QFont font;
    font.setPointSize(10);
    axisX->setLabelsFont(font);
    int tickCount ;
    if(temperatures.size()<=10)   {
        tickCount=5;
    }
    else  if(temperatures.size()>10&&temperatures.size()<=100){
        tickCount=7;
    }

    axisX->setTickCount(tickCount);
    chart->setAxisX(axisX, series);

    // 创建并设置Y轴（假设Y轴数据为整数）
    QValueAxis *axisY = new QValueAxis();
    axisY->setLabelFormat("%i");
    if(ui->comboBox->currentText()=="温度"){
        axisY->setTitleText("温度 (°C)");
        chart->setTitle("历史温度数据");
    }
    else if(ui->comboBox->currentText()=="湿度"){
        axisY->setTitleText("湿度 (%)");
        chart->setTitle("历史湿度数据");
    }
    else if(ui->comboBox->currentText()=="光强"){
        axisY->setTitleText("光强 (lx)");
        chart->setTitle("历史光强数据");
    }
    else if(ui->comboBox->currentText()=="震动"){
        axisY->setTitleText("震动 (µg/m³)");
        chart->setTitle("历史震动数据");
    }
    else if(ui->comboBox->currentText()=="烟雾"){
        axisY->setTitleText("烟雾 (ppm)");
        chart->setTitle("历史烟雾数据");
    }
    axisY->applyNiceNumbers();
    chart->setAxisY(axisY, series);

    // 设置图表主题
    chart->setTheme(QChart::ChartThemeBlueCerulean);

    // 将图表设置到视图
    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing); // 设置抗锯齿，以改善图形的视觉质量
}
void past_records::timer_sishi()
{
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        QSqlDatabase::removeDatabase("qt_sql_default_connection");
    }

    // 添加新的数据库连接
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "qt_sql_default_connection");
    db.setDatabaseName("lyshark.db");
    if (!db.open()) {
        std::cout << db.lastError().text().toStdString() << std::endl;
        return;
    }

    // 执行查询获取最新的10000个数据
    QSqlQuery query(db);
    if(ui->comboBox_2->currentText()=="一"){
        if(ui->comboBox->currentText()=="温度"){
            query.prepare("SELECT datetime, temprature FROM Times1 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="湿度"){
            query.prepare("SELECT datetime, humidity FROM Times1 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="光强"){
            query.prepare("SELECT datetime, light FROM Times1 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="震动"){
            query.prepare("SELECT datetime, dust FROM Times1 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="烟雾"){
            query.prepare("SELECT datetime, fog FROM Times1 ORDER BY id DESC LIMIT 10000");
        }
    }
    else if(ui->comboBox_2->currentText()=="二"){
        if(ui->comboBox->currentText()=="温度"){
            query.prepare("SELECT datetime, temprature FROM Times2 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="湿度"){
            query.prepare("SELECT datetime, humidity FROM Times2 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="光强"){
            query.prepare("SELECT datetime, light FROM Times2 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="震动"){
            query.prepare("SELECT datetime, dust FROM Times2 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="烟雾"){
            query.prepare("SELECT datetime, fog FROM Times2 ORDER BY id DESC LIMIT 10000");
        }
    }
    else if(ui->comboBox_2->currentText()=="三"){
        if(ui->comboBox->currentText()=="温度"){
            query.prepare("SELECT datetime, temprature FROM Times3 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="湿度"){
            query.prepare("SELECT datetime, humidity FROM Times3 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="光强"){
            query.prepare("SELECT datetime, light FROM Times3 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="震动"){
            query.prepare("SELECT datetime, dust FROM Times3 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="烟雾"){
            query.prepare("SELECT datetime, fog FROM Times3 ORDER BY id DESC LIMIT 10000");
        }
    }
    if (!query.exec()) {
        std::cout << query.lastError().text().toStdString() << std::endl;
        return;
    }

    QVector<int> temperature_data;
    QVector<QString> datetimes;
    while (query.next()) {
        QString datetime = query.value(0).toString();
        int temperature = query.value(1).toInt();
        datetimes.prepend(datetime);        // 将时间添加到向量的开始，保证顺序
        temperature_data.prepend(temperature); // 将温度添加到向量的开始，保证顺序
    }
    plotArrayData_sishi(datetimes,temperature_data);  // 调用之前实现的函数来绘制这些数据
    db.close();
}
int sishi_flag=0;
void past_records::on_pushButton_2_clicked()
{
    sishi_flag=0;
    ui->pushButton_3->setText("OFF");
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        QSqlDatabase::removeDatabase("qt_sql_default_connection");
    }

    // 添加新的数据库连接
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "qt_sql_default_connection");
    db.setDatabaseName("lyshark.db");
    if (!db.open()) {
        std::cout << db.lastError().text().toStdString() << std::endl;
        return;
    }

    // 执行查询获取最新的10000个数据
    QSqlQuery query(db);
    if(ui->comboBox_2->currentText()=="一"){
        if(ui->comboBox->currentText()=="温度"){
            query.prepare("SELECT datetime, temprature FROM Times1 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="湿度"){
            query.prepare("SELECT datetime, humidity FROM Times1 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="光强"){
            query.prepare("SELECT datetime, light FROM Times1 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="震动"){
            query.prepare("SELECT datetime, dust FROM Times1 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="烟雾"){
            query.prepare("SELECT datetime, fog FROM Times1 ORDER BY id DESC LIMIT 10000");
        }
    }
    else if(ui->comboBox_2->currentText()=="二"){
        if(ui->comboBox->currentText()=="温度"){
            query.prepare("SELECT datetime, temprature FROM Times2 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="湿度"){
            query.prepare("SELECT datetime, humidity FROM Times2 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="光强"){
            query.prepare("SELECT datetime, light FROM Times2 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="震动"){
            query.prepare("SELECT datetime, dust FROM Times2 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="烟雾"){
            query.prepare("SELECT datetime, fog FROM Times2 ORDER BY id DESC LIMIT 10000");
        }
    }
    else if(ui->comboBox_2->currentText()=="三"){
        if(ui->comboBox->currentText()=="温度"){
            query.prepare("SELECT datetime, temprature FROM Times3 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="湿度"){
            query.prepare("SELECT datetime, humidity FROM Times3 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="光强"){
            query.prepare("SELECT datetime, light FROM Times3 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="震动"){
            query.prepare("SELECT datetime, dust FROM Times3 ORDER BY id DESC LIMIT 10000");
        }
        else if(ui->comboBox->currentText()=="烟雾"){
            query.prepare("SELECT datetime, fog FROM Times3 ORDER BY id DESC LIMIT 10000");
        }
    }

    if (!query.exec()) {
        std::cout << query.lastError().text().toStdString() << std::endl;
        return;
    }

    QVector<int> temperature_data;
    QVector<QString> datetimes;
    while (query.next()) {
        QString datetime = query.value(0).toString();
        int temperature = query.value(1).toInt();
        datetimes.prepend(datetime);        // 将时间添加到向量的开始，保证顺序
        temperature_data.prepend(temperature); // 将温度添加到向量的开始，保证顺序
    }
    plotArrayData(datetimes,temperature_data);  // 调用之前实现的函数来绘制这些数据
    db.close();
}


void past_records::on_pushButton_3_clicked()
{
//    timer_sishi();
    if(sishi_flag==1){
        ui->pushButton_3->setText("OFF");
        sishi_flag=0;
    }
    else {
        ui->pushButton_3->setText("ON");
        sishi_flag=1;
    }
}
void past_records::timer_task()
{
    if(sishi_flag==0){
    }
    else {
        timer_sishi();
    }
}
