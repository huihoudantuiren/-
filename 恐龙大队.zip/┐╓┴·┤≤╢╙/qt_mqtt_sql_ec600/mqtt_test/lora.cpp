#include "QDebug"
#include "QPushButton"
#include "lora.h"

lora::lora(){

}

lora::~lora() {
    if (serial.isOpen())
        serial.close();
}

bool lora::writeToSerialPort(const QString &portName, const QByteArray &message) {
    QSerialPort serial;
    serial.setPortName(portName);
    serial.setBaudRate(QSerialPort::Baud9600);
    serial.setDataBits(QSerialPort::Data8);
    serial.setParity(QSerialPort::NoParity);
    serial.setStopBits(QSerialPort::OneStop);
    serial.setFlowControl(QSerialPort::NoFlowControl);

    if (!serial.open(QIODevice::ReadWrite)) {
        qDebug() << "Failed to open port" << portName << ", error:" << serial.errorString();
        return false;
    }

    if (serial.write(message) == -1) {
        qDebug() << "Failed to write data to port" << portName << ", error:" << serial.errorString();
        serial.close();
        return false;
    }

    serial.flush();
    serial.close();
    return true;
}

QByteArray lora::readFromSerialPort(const QString &portName) {
    QSerialPort serial;
    serial.setPortName(portName);
    serial.setBaudRate(QSerialPort::Baud9600);
    serial.setDataBits(QSerialPort::Data8);
    serial.setParity(QSerialPort::NoParity);
    serial.setStopBits(QSerialPort::OneStop);
    serial.setFlowControl(QSerialPort::NoFlowControl);

    if (!serial.open(QIODevice::ReadOnly)) {
        qDebug() << "Failed to open port" << portName << ", error:" << serial.errorString();
        return QByteArray();
    }

    QByteArray readData;
    if (serial.waitForReadyRead(200)) {
        readData = serial.readAll();
        while (serial.waitForReadyRead(100))
            readData.append(serial.readAll());
    }

    serial.close();
    return readData;
}
void lora::sendloraMessage(const QByteArray &message)
{
    QString portName = uart_lora;
    lora serial;

    if(serial.writeToSerialPort(portName, message)) {
        qDebug() << "message written successfully to" << portName << "message:" << message;
    } else {
        qDebug() << "Failed to write message to" << portName;
    }
    sleep(0.5);
}
void lora::init_lora()
{
    QString portName = uart_lora;//串口地址
    lora serial;
    serial.listPorts();

    // 从串口读取数据1
    QByteArray receivedData = serial.readFromSerialPort(portName);
    if (!receivedData.isEmpty()) {
        qDebug() << "Received data from" << portName << ":" << receivedData;
    } else {
        qDebug() << "No data received from" << portName << "or read timeout.";
    }
}
void lora::listPorts()
{
    QList<QSerialPortInfo> serialPortInfos = QSerialPortInfo::availablePorts();
    qDebug() << "Total numbers of ports: " << serialPortInfos.count();
    foreach (const QSerialPortInfo &portInfo, serialPortInfos) {
        qDebug() << "Port:" << portInfo.portName();
    }
}

bool lora::initializePort(const QString &portName)
{
    serial.setPortName(portName);
    if (!serial.open(QIODevice::ReadWrite)) {
        qDebug() << "Failed to open port" << portName << "with error:" << serial.errorString();
        return false;
    }

    serial.setBaudRate(QSerialPort::Baud9600);
    serial.setDataBits(QSerialPort::Data8);
    serial.setParity(QSerialPort::NoParity);
    serial.setStopBits(QSerialPort::OneStop);
    serial.setFlowControl(QSerialPort::NoFlowControl);

    qDebug() << "Serial port" << portName << "initialized successfully.";
    return true;
}
bool lora::writeData(const QString &portName, const QByteArray &data) {
    QSerialPort* port = getSerialPort(portName);
    if (!port || port->write(data) == -1) {
        qDebug() << "Failed to write data to port: " << portName << ", with error: " << (port ? port->errorString() : "Port not initialized");
        return false;
    }
    port->waitForBytesWritten(-1);
    return true;
}

QByteArray lora::readData(const QString &portName) {
    QByteArray data;
    QSerialPort* port = getSerialPort(portName);
    if (port && port->waitForReadyRead(100)) {
        data = port->readAll();
        while (port->waitForReadyRead(100)) {
            data += port->readAll();
        }
    }
    return data;
}

QSerialPort* lora::getSerialPort(const QString &portName) {
    if (serial.portName() == portName && serial.isOpen())
        return &serial;
    else
        return nullptr;  // In a complete implementation, you'd manage multiple ports here.
}
