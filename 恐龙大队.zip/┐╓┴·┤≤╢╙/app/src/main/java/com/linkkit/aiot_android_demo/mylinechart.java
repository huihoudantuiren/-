package com.linkkit.aiot_android_demo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.Spinner;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;
import java.util.List;

public class mylinechart extends AppCompatActivity {

    private LineChart lineChart;
    private Spinner id_sp;

    String temperature_sql[] = new String[1000];
    String light_sql[] = new String[1000];
    String humidity_sql[] = new String[1000];
    String fog_sql[] = new String[1000];
    String dust_sql[] = new String[1000];





    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.line_display);

        InitChart();
        setupSpinner();
        lineChart.invalidate();

    }

    private void InitChart(){
        lineChart = findViewById(R.id.line_chart);
        //设置背景
        lineChart.setBackgroundColor(Color.WHITE);
        //是否显示坐标数据
        lineChart.getDescription().setEnabled(false);
        //是否支持双击
        lineChart.setTouchEnabled(true);
        //值选中回调监听
        lineChart.setDrawGridBackground(false);
        //显示坐标数据的box
        lineChart.setScaleEnabled(true);
        lineChart.setDragEnabled(true);
        //是否可以拖动
        lineChart.setScaleEnabled(true);
        // 是否可以缩放
        lineChart.setPinchZoom(true);
        lineChart.fitScreen();

        XAxis xAxis;
        {   // X-Axis Style //
            xAxis = lineChart.getXAxis();
            // vertical grid lines
            xAxis.enableGridDashedLine(10f, 10f, 0f);
        }
        YAxis yAxis;
        {   // // Y-Axis Style // //
            yAxis = lineChart.getAxisLeft();
            // disable dual axis (only use LEFT axis)
            lineChart.getAxisRight().setEnabled(false);
            // horizontal grid lines
            yAxis.enableGridDashedLine(10f, 10f, 0f);
            // axis range
            yAxis.setAxisMaximum(1000f);
            yAxis.setAxisMinimum(-10f);
        }
    }

    private void setupSpinner() {

        DBOpenHelper dbsqLiteOpenHelper = new DBOpenHelper(mylinechart.this,"users.db",null,1);
        SQLiteDatabase db = dbsqLiteOpenHelper.getWritableDatabase();

        id_sp = findViewById(R.id.spinner_line);









        //创建游标对象


        id_sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String selectedItem_id = (String)id_sp.getSelectedItem();

                if (selectedItem_id.equals("车间一")){
                    Cursor cursor_temperature_id1 = db.query("user", new String[]{"temperature"}, "_id = ?",
                            new String[]{"1"}, null, null, null);
                    //利用游标遍历所有数据对象
                    int num_sql_read = 0;
                    while(cursor_temperature_id1.moveToNext()){
                        temperature_sql[num_sql_read] = cursor_temperature_id1.getString(cursor_temperature_id1.getColumnIndex("temperature"));
                        num_sql_read++;
                    }cursor_temperature_id1.close();// 关闭游标，释放资源

                    Cursor cursor_light_id1 = db.query("user", new String[]{"light"}, "_id = ?",
                            new String[]{"1"}, null, null, null);
                    num_sql_read = 0;
                    while(cursor_light_id1.moveToNext()){
                        light_sql[num_sql_read] = cursor_light_id1.getString(cursor_light_id1.getColumnIndex("light"));
                        num_sql_read++;
                    }cursor_light_id1.close();// 关闭游标，释放资源

                    Cursor cursor_humidity_id1 = db.query("user", new String[]{"humidity"}, "_id = ?",
                            new String[]{"1"}, null, null, null);
                    num_sql_read = 0;
                    while(cursor_humidity_id1.moveToNext()){
                        humidity_sql[num_sql_read] = cursor_humidity_id1.getString(cursor_humidity_id1.getColumnIndex("humidity"));
                        num_sql_read++;
                    }cursor_humidity_id1.close();// 关闭游标，释放资源

                    Cursor cursor_fog_id1 = db.query("user", new String[]{"fog"}, "_id = ?",
                            new String[]{"1"}, null, null, null);
                    num_sql_read = 0;
                    while(cursor_fog_id1.moveToNext()){
                        fog_sql[num_sql_read] = cursor_fog_id1.getString(cursor_fog_id1.getColumnIndex("fog"));
                        num_sql_read++;
                    }cursor_fog_id1.close();// 关闭游标，释放资源

                    Cursor cursor_dust_id1 = db.query("user", new String[]{"dust"}, "_id = ?",
                            new String[]{"1"}, null, null, null);
                    num_sql_read = 0;
                    while(cursor_dust_id1.moveToNext()){
                        dust_sql[num_sql_read] = cursor_dust_id1.getString(cursor_dust_id1.getColumnIndex("dust"));
                        num_sql_read++;
                    }cursor_dust_id1.close();// 关闭游标，释放资源
                    setData();
                    lineChart.invalidate();

                }
                if (selectedItem_id.equals("车间二")){
                    Cursor cursor_temperature_id2 = db.query("user", new String[]{"temperature"}, "_id = ?",
                            new String[]{"2"}, null, null, null);
                    //利用游标遍历所有数据对象
                    int num_sql_read = 0;
                    while(cursor_temperature_id2.moveToNext()){
                        temperature_sql[num_sql_read] = cursor_temperature_id2.getString(cursor_temperature_id2.getColumnIndex("temperature"));
                        num_sql_read++;
                    }cursor_temperature_id2.close();// 关闭游标，释放资源

                    Cursor cursor_light_id2 = db.query("user", new String[]{"light"}, "_id = ?",
                            new String[]{"2"}, null, null, null);
                    num_sql_read = 0;
                    while(cursor_light_id2.moveToNext()){
                        light_sql[num_sql_read] = cursor_light_id2.getString(cursor_light_id2.getColumnIndex("light"));
                        num_sql_read++;
                    }cursor_light_id2.close();// 关闭游标，释放资源

                    Cursor cursor_humidity_id2 = db.query("user", new String[]{"humidity"}, "_id = ?",
                            new String[]{"2"}, null, null, null);
                    num_sql_read = 0;
                    while(cursor_humidity_id2.moveToNext()){
                        humidity_sql[num_sql_read] = cursor_humidity_id2.getString(cursor_humidity_id2.getColumnIndex("humidity"));
                        num_sql_read++;
                    }cursor_humidity_id2.close();// 关闭游标，释放资源

                    Cursor cursor_fog_id2 = db.query("user", new String[]{"fog"}, "_id = ?",
                            new String[]{"2"}, null, null, null);
                    num_sql_read = 0;
                    while(cursor_fog_id2.moveToNext()){
                        fog_sql[num_sql_read] = cursor_fog_id2.getString(cursor_fog_id2.getColumnIndex("fog"));
                        num_sql_read++;
                    }cursor_fog_id2.close();// 关闭游标，释放资源

                    Cursor cursor_dust_id2 = db.query("user", new String[]{"dust"}, "_id = ?",
                            new String[]{"2"}, null, null, null);
                    num_sql_read = 0;
                    while(cursor_dust_id2.moveToNext()){
                        dust_sql[num_sql_read] = cursor_dust_id2.getString(cursor_dust_id2.getColumnIndex("dust"));
                        num_sql_read++;
                    }cursor_dust_id2.close();// 关闭游标，释放资源
                    setData();
                    lineChart.invalidate();

                }
                if (selectedItem_id.equals("车间三")){
                    Cursor cursor_temperature_id3 = db.query("user", new String[]{"temperature"}, "_id = ?",
                            new String[]{"3"}, null, null, null);
                    //利用游标遍历所有数据对象
                    int num_sql_read = 0;
                    while(cursor_temperature_id3.moveToNext()){
                        temperature_sql[num_sql_read] = cursor_temperature_id3.getString(cursor_temperature_id3.getColumnIndex("temperature"));
                        num_sql_read++;
                    }cursor_temperature_id3.close();// 关闭游标，释放资源

                    Cursor cursor_light_id3 = db.query("user", new String[]{"light"}, "_id = ?",
                            new String[]{"3"}, null, null, null);
                    num_sql_read = 0;
                    while(cursor_light_id3.moveToNext()){
                        light_sql[num_sql_read] = cursor_light_id3.getString(cursor_light_id3.getColumnIndex("light"));
                        num_sql_read++;
                    }cursor_light_id3.close();// 关闭游标，释放资源

                    Cursor cursor_humidity_id3 = db.query("user", new String[]{"humidity"}, "_id = ?",
                            new String[]{"3"}, null, null, null);
                    num_sql_read = 0;
                    while(cursor_humidity_id3.moveToNext()){
                        humidity_sql[num_sql_read] = cursor_humidity_id3.getString(cursor_humidity_id3.getColumnIndex("humidity"));
                        num_sql_read++;
                    }cursor_humidity_id3.close();// 关闭游标，释放资源

                    Cursor cursor_fog_id3 = db.query("user", new String[]{"fog"}, "_id = ?",
                            new String[]{"3"}, null, null, null);
                    num_sql_read = 0;
                    while(cursor_fog_id3.moveToNext()){
                        fog_sql[num_sql_read] = cursor_fog_id3.getString(cursor_fog_id3.getColumnIndex("fog"));
                        num_sql_read++;
                    }cursor_fog_id3.close();// 关闭游标，释放资源

                    Cursor cursor_dust_id3 = db.query("user", new String[]{"dust"}, "_id = ?",
                            new String[]{"3"}, null, null, null);
                    num_sql_read = 0;
                    while(cursor_dust_id3.moveToNext()){
                        dust_sql[num_sql_read] = cursor_dust_id3.getString(cursor_dust_id3.getColumnIndex("dust"));
                        num_sql_read++;
                    }cursor_dust_id3.close();// 关闭游标，释放资源
                    setData();
                    lineChart.invalidate();

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void setData() {

        CheckBox cb_temperature = findViewById(R.id.cb_temperature);
        CheckBox cb_light = findViewById(R.id.cb_light);
        CheckBox cb_humidity = findViewById(R.id.cb_humidity);
        CheckBox cb_fog = findViewById(R.id.cb_fog);
        CheckBox cb_dust = findViewById(R.id.cb_dust);

        //========================================================================
        List<Entry> entries_1 = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            if (temperature_sql[i] == null)break;
            entries_1.add(new Entry(i, Float.valueOf(temperature_sql[i])));
        } //一个LineDataSet就是一条线
        LineDataSet lineDataSet = new LineDataSet(entries_1, "温度");

        lineDataSet.setColor(Color.RED);//线颜色设置
        lineDataSet.setDrawCircleHole(false);//设置曲线值的圆点是实心还是空心
        lineDataSet.setValueTextSize(9f);//设置显示值的字体大小
        lineDataSet.setCircleSize(3f);//数据点大小设置
        lineDataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);//线模式为圆滑曲线（默认折线）
        lineDataSet.setCircleColor(Color.RED);//数据点颜色设置
        lineDataSet.setValueTextColor(Color.RED);//数据文本颜色设置

        //========================================================================
        List<Entry> entries_2 = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            if (light_sql[i] == null)break;
            entries_2.add(new Entry(i, Float.valueOf(light_sql[i])));
        } //一个LineDataSet就是一条线
        LineDataSet lineDataSet2 = new LineDataSet(entries_2, "光照");

        lineDataSet2.setColor(Color.BLUE);//线颜色设置
        lineDataSet2.setDrawCircleHole(false);//设置曲线值的圆点是实心还是空心
        lineDataSet2.setValueTextSize(9f);//设置显示值的字体大小
        lineDataSet2.setCircleSize(3f);//数据点大小设置
        lineDataSet2.setMode(LineDataSet.Mode.CUBIC_BEZIER);//线模式为圆滑曲线（默认折线）
        lineDataSet2.setCircleColor(Color.BLUE);//数据点颜色设置
        lineDataSet2.setValueTextColor(Color.BLUE);//数据文本颜色设置

        //========================================================================
        List<Entry> entries_3 = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            if (humidity_sql[i] == null)break;
            entries_3.add(new Entry(i, Float.valueOf(humidity_sql[i])));
        } //一个LineDataSet就是一条线
        LineDataSet lineDataSet3 = new LineDataSet(entries_3, "湿度");

        lineDataSet3.setColor(Color.GREEN);//线颜色设置
        lineDataSet3.setDrawCircleHole(false);//设置曲线值的圆点是实心还是空心
        lineDataSet3.setValueTextSize(9f);//设置显示值的字体大小
        lineDataSet3.setCircleSize(3f);//数据点大小设置
        lineDataSet3.setMode(LineDataSet.Mode.CUBIC_BEZIER);//线模式为圆滑曲线（默认折线）
        lineDataSet3.setCircleColor(Color.GREEN);//数据点颜色设置
        lineDataSet3.setValueTextColor(Color.GREEN);//数据文本颜色设置

        //========================================================================
        List<Entry> entries_4 = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            if (fog_sql[i] == null)break;
            entries_4.add(new Entry(i, Float.valueOf(fog_sql[i])));
        } //一个LineDataSet就是一条线
        LineDataSet lineDataSet4 = new LineDataSet(entries_4, "烟雾");

        lineDataSet4.setColor(Color.GRAY);//线颜色设置
        lineDataSet4.setDrawCircleHole(false);//设置曲线值的圆点是实心还是空心
        lineDataSet4.setValueTextSize(9f);//设置显示值的字体大小
        lineDataSet4.setCircleSize(3f);//数据点大小设置
        lineDataSet4.setMode(LineDataSet.Mode.CUBIC_BEZIER);//线模式为圆滑曲线（默认折线）
        lineDataSet4.setCircleColor(Color.GRAY);//数据点颜色设置
        lineDataSet4.setValueTextColor(Color.GRAY);//数据文本颜色设置

        //========================================================================
        List<Entry> entries_5 = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            if (dust_sql[i] == null)break;
            entries_5.add(new Entry(i, Float.valueOf(dust_sql[i])));
        } //一个LineDataSet就是一条线
        LineDataSet lineDataSet5 = new LineDataSet(entries_5, "震动");

        lineDataSet5.setColor(Color.BLACK);//线颜色设置
        lineDataSet5.setDrawCircleHole(false);//设置曲线值的圆点是实心还是空心
        lineDataSet5.setValueTextSize(9f);//设置显示值的字体大小
        lineDataSet5.setCircleSize(3f);//数据点大小设置
        lineDataSet5.setMode(LineDataSet.Mode.CUBIC_BEZIER);//线模式为圆滑曲线（默认折线）
        lineDataSet5.setCircleColor(Color.BLACK);//数据点颜色设置
        lineDataSet5.setValueTextColor(Color.BLACK);//数据文本颜色设置

        LineData data = new LineData(lineDataSet,lineDataSet2,lineDataSet3,lineDataSet4,lineDataSet5);

        cb_temperature.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // 根据复选框状态更新图表数据
            if (isChecked) {
                // 在图表上显示数据 1
                lineDataSet.setVisible(true);
            } else {
                // 从图表上隐藏数据 1
                lineDataSet.setVisible(false);
            }
            // 刷新图表
            lineChart.invalidate();
        });

        cb_light.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // 根据复选框状态更新图表数据
            if (isChecked) {
                // 在图表上显示数据 2
                lineDataSet2.setVisible(true);
            } else {
                // 从图表上隐藏数据 2
                lineDataSet2.setVisible(false);
            }
            // 刷新图表
            lineChart.invalidate();
        });

        cb_humidity.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // 根据复选框状态更新图表数据
            if (isChecked) {
                // 在图表上显示数据 3
                lineDataSet3.setVisible(true);
            } else {
                // 从图表上隐藏数据 3
                lineDataSet3.setVisible(false);
            }
            // 刷新图表
            lineChart.invalidate();
        });

        cb_fog.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // 根据复选框状态更新图表数据
            if (isChecked) {
                // 在图表上显示数据 4
                lineDataSet4.setVisible(true);
            } else {
                // 从图表上隐藏数据 4
                lineDataSet4.setVisible(false);
            }
            // 刷新图表
            lineChart.invalidate();
        });

        cb_dust.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // 根据复选框状态更新图表数据
            if (isChecked) {
                // 在图表上显示数据 5
                lineDataSet5.setVisible(true);
            } else {
                // 从图表上隐藏数据 5
                lineDataSet5.setVisible(false);
            }
            // 刷新图表
            lineChart.invalidate();
        });

        lineChart.setData(data);

    }
}

