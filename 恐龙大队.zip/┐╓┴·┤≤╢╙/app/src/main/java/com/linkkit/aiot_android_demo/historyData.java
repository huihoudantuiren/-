package com.linkkit.aiot_android_demo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class historyData extends AppCompatActivity {

    private final String TAG = "historydata";
    private Spinner id_sp;
    private Spinner data_sp;

//    String from[] = new String[]{"userid", "zd_id", "data", "temperature", "light", "humidity", "fog", "dust"};
    String from_temperature[] = new String[]{"time", "temperature"};
    String from_light[] = new String[]{"time", "light"};
    String from_humidity[] = new String[]{"time", "humidity"};
    String from_fog[] = new String[]{"time", "fog"};
    String from_dust[] = new String[]{"time", "dust"};
    int[] to = new int[]{R.id.sql_time, R.id.sql_data};

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display);

        DBOpenHelper dbsqLiteOpenHelper = new DBOpenHelper(historyData.this,"users.db",null,1);
        SQLiteDatabase db = dbsqLiteOpenHelper.getWritableDatabase();

        Button button_delete = findViewById(R.id.button_clear);

        id_sp = findViewById(R.id.spinner_id);
        data_sp = findViewById(R.id.spinner_data);
        TextView data_sql = findViewById(R.id.textView_data_sql);

        id_sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                updateListView();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        data_sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                data_sql.setText(data_sp.getSelectedItem().toString());
                updateListView();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        button_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.delete("user",null,null);
            }
        });

    }

    private void updateListView() {
        String selectedItem_id = (String)id_sp.getSelectedItem();
        String selectedItem_data = (String)data_sp.getSelectedItem();

        DBOpenHelper dbsqLiteOpenHelper = new DBOpenHelper(historyData.this,"users.db",null,1);
        SQLiteDatabase db = dbsqLiteOpenHelper.getWritableDatabase();

        Cursor cursor_temperature_id1 = db.query("user", new String[]{"_id","time","temperature"}, "_id = ?", new String[]{"1"}, null, null, null);
        Cursor cursor_light_id1 = db.query("user", new String[]{"_id","time","light"}, "_id = ?", new String[]{"1"}, null, null, null);
        Cursor cursor_humidity_id1 = db.query("user", new String[]{"_id","time","humidity"}, "_id = ?", new String[]{"1"}, null, null, null);
        Cursor cursor_fog_id1 = db.query("user", new String[]{"_id","time","fog"}, "_id = ?", new String[]{"1"}, null, null, null);
        Cursor cursor_dust_id1 = db.query("user", new String[]{"_id","time","dust"}, "_id = ?", new String[]{"1"}, null, null, null);

        Cursor cursor_temperature_id2 = db.query("user", new String[]{"_id","time","temperature"}, "_id = ?", new String[]{"2"}, null, null, null);
        Cursor cursor_light_id2 = db.query("user", new String[]{"_id","time","light"}, "_id = ?", new String[]{"2"}, null, null, null);
        Cursor cursor_humidity_id2 = db.query("user", new String[]{"_id","time","humidity"}, "_id = ?", new String[]{"2"}, null, null, null);
        Cursor cursor_fog_id2 = db.query("user", new String[]{"_id","time","fog"}, "_id = ?", new String[]{"2"}, null, null, null);
        Cursor cursor_dust_id2 = db.query("user", new String[]{"_id","time","dust"}, "_id = ?", new String[]{"2"}, null, null, null);

        Cursor cursor_temperature_id3 = db.query("user", new String[]{"_id","time","temperature"}, "_id = ?", new String[]{"3"}, null, null, null);
        Cursor cursor_light_id3 = db.query("user", new String[]{"_id","time","light"}, "_id = ?", new String[]{"3"}, null, null, null);
        Cursor cursor_humidity_id3 = db.query("user", new String[]{"_id","time","humidity"}, "_id = ?", new String[]{"3"}, null, null, null);
        Cursor cursor_fog_id3 = db.query("user", new String[]{"_id","time","fog"}, "_id = ?", new String[]{"3"}, null, null, null);
        Cursor cursor_dust_id3 = db.query("user", new String[]{"_id","time","dust"}, "_id = ?", new String[]{"3"}, null, null, null);

        SimpleCursorAdapter adapter_temperature_id1 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_temperature_id1, from_temperature, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        SimpleCursorAdapter adapter_light_id1 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_light_id1, from_light, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        SimpleCursorAdapter adapter_humidity_id1 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_humidity_id1, from_humidity, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        SimpleCursorAdapter adapter_fog_id1 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_fog_id1, from_fog, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        SimpleCursorAdapter adapter_dust_id1 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_dust_id1, from_dust, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);

        SimpleCursorAdapter adapter_temperature_id2 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_temperature_id2, from_temperature, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        SimpleCursorAdapter adapter_light_id2 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_light_id2, from_light, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        SimpleCursorAdapter adapter_humidity_id2 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_humidity_id2,from_humidity, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        SimpleCursorAdapter adapter_fog_id2 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_fog_id2, from_fog, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        SimpleCursorAdapter adapter_dust_id2 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_dust_id2, from_dust, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);

        SimpleCursorAdapter adapter_temperature_id3 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_temperature_id3, from_temperature, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        SimpleCursorAdapter adapter_light_id3 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_light_id3, from_light, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        SimpleCursorAdapter adapter_humidity_id3 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_humidity_id3, from_humidity, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        SimpleCursorAdapter adapter_fog_id3 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_fog_id3, from_fog, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        SimpleCursorAdapter adapter_dust_id3 = new SimpleCursorAdapter(this, R.layout.historydata, cursor_dust_id3, from_dust, to, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);

        ListView list_view = findViewById(R.id.list_view);

        if (selectedItem_id.equals("车间一")){
            if (selectedItem_data.equals("温度")){
                list_view.setAdapter(adapter_temperature_id1);
            }
            if (selectedItem_data.equals("光照")){
                list_view.setAdapter(adapter_light_id1);
            }
            if (selectedItem_data.equals("湿度")){
                list_view.setAdapter(adapter_humidity_id1);
            }
            if (selectedItem_data.equals("烟雾")){
                list_view.setAdapter(adapter_fog_id1);
            }
            if (selectedItem_data.equals("灰尘")){
                list_view.setAdapter(adapter_dust_id1);
            }
        }
        if (selectedItem_id.equals("车间二")){
            if (selectedItem_data.equals("温度")){
                list_view.setAdapter(adapter_temperature_id2);
            }
            if (selectedItem_data.equals("光照")){
                list_view.setAdapter(adapter_light_id2);
            }
            if (selectedItem_data.equals("湿度")){
                list_view.setAdapter(adapter_humidity_id2);
            }
            if (selectedItem_data.equals("烟雾")){
                list_view.setAdapter(adapter_fog_id2);
            }
            if (selectedItem_data.equals("灰尘")){
                list_view.setAdapter(adapter_dust_id2);
            }
        }
        if (selectedItem_id.equals("车间三")){
            if (selectedItem_data.equals("温度")){
                list_view.setAdapter(adapter_temperature_id3);
            }
            if (selectedItem_data.equals("光照")){
                list_view.setAdapter(adapter_light_id3);
            }
            if (selectedItem_data.equals("湿度")){
                list_view.setAdapter(adapter_humidity_id3);
            }
            if (selectedItem_data.equals("烟雾")){
                list_view.setAdapter(adapter_fog_id3);
            }
            if (selectedItem_data.equals("灰尘")){
                list_view.setAdapter(adapter_dust_id3);
            }
        }
    }

}


