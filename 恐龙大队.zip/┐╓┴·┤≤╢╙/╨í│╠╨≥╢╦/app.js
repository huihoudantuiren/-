App({
  onLaunch: function () {
    wx.cloud.init({
      // env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
      env: 'loong-wechat-9g31m08qcbf6ba47',
      // 是否在将用户访问记录到用户管理中，在控制台中可见，默认为false
      traceUser: false,
    });
  },
  globalData: {
  
    receivedata:{
      cli:null,
      temperature1:"",
      humidity1:"",
      light1:"",
      dust1:"",
      fog1:"",
      temperature2:"",
      humidity2:"",
      light2:"",
      dust2:"",
      fog2:"",
      temperature3:"",
      humidity3:"",
      light3:"",
      dust3:"",
      fog3:"",
      receive_text:"",
    }
    }
  }
)