// pages/index4/index4.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentPage: 0,
    modes: ['车间一', '车间二', '车间三'],  // 可选择的模式
    currentMode: '车间一',  // 默认模式
    zd: '',  // 这里是你的变量zd，可以根据需要进行初始化
    parameters: ['温度', '湿度', '光强', '震动', '烟雾'],
    currentParameter: '温度',  // 默认参数
    listData: [] ,
    currentTime: null,
  },

  onClickOpen: function() {
    const currentTime = new Date().toISOString();
    this.setData({ currentTime });
    console.log("当前时间:", currentTime);
    wx.showToast({
      title: '历史数据已清空',
      icon: 'success',
      duration: 2000
    });
    this.fetchData(this.data.currentMode);
  },
  onClickOff: function() {
    this.setData({ currentTime: null, isLoading: true });
    console.log("当前时间:", this.data.currentTime);
    wx.showToast({
      title: '获取历史数据中',
      icon: 'loading',
      duration: 3000
    });
    setTimeout(() => {
      wx.showToast({
        title: '数据获取完毕',
        icon: 'success',
        duration: 500
      });
      this.fetchData(this.data.currentMode);
    }, 5000);
  },
  prevPage: function() {
    if (this.data.currentPage > 0) {
      this.setData({
        currentPage: this.data.currentPage - 1
      }, () => {
        this.fetchData(this.data.currentMode);
      });
    }
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300 // 滚动动画持续时间，单位ms
    });
  },

  // 下一页
  nextPage: function() {
    this.setData({
      currentPage: this.data.currentPage + 1
    }, () => {
      this.fetchData(this.data.currentMode);
    });
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 300 // 滚动动画持续时间，单位ms
    });
  },
  changeParameter: function(e) {
    const selectedParameter = this.data.parameters[e.detail.value];
    this.setData({
      currentParameter: selectedParameter
    })
    this.fetchData(this.data.currentMode);
    ;
  },
  changeMode: function(e) {
    const selectedMode = this.data.modes[e.detail.value];
    this.setData({
        currentMode: selectedMode,
        zd: selectedMode  // 将选择的模式保存到zd变量
    }
    ),
    this.fetchData(this.data.currentMode);
},
fetchData: function(mode) {
  let tableMap = {
    '车间一': 'table1',
    '车间二': 'table2',
    '车间三': 'table3'
  };
  let temp = tableMap[mode] || 'table1'; // 默认为table1，如果mode不在tableMap中
  const { currentPage, currentTime, currentParameter } = this.data;
  let query = wx.cloud.database().collection(temp)
    .orderBy('date_time', 'desc')
    .skip(currentPage * 20);

    if (currentTime) {
      const currentTimeDate = new Date(currentTime);
  
      // 转换为 yyyy-MM-dd HH:mm:ss 格式
      const year = currentTimeDate.getFullYear();
      const month = String(currentTimeDate.getMonth() + 1).padStart(2, '0');
      const day = String(currentTimeDate.getDate()).padStart(2, '0');
      const hours = String(currentTimeDate.getHours()).padStart(2, '0');
      const minutes = String(currentTimeDate.getMinutes()).padStart(2, '0');
      const seconds = String(currentTimeDate.getSeconds()).padStart(2, '0');
  
      const formattedCurrentTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  
      query = query.where({
          date_time: wx.cloud.database().command.gte(formattedCurrentTime)
      });
  }

  query.get({
    success: res => {
      console.log('请求成功', res); // res.data包含该记录的数据
      let temp = [];
      switch (this.data.currentParameter) {
        case "温度":
          console.log(this.data.currentParameter);
          temp = res.data.map(item => ({
            name: item.name,
            style: item.temperature,
            datetime: item.date_time
          }));
          break;
        case "湿度":
          temp = res.data.map(item => ({
            name: item.name,
            style: item.humidity,
            datetime: item.date_time
          }));
          break;
        case "光强":
          temp = res.data.map(item => ({
            name: item.name,
            style: item.light,
            datetime: item.date_time
          }));
          break;
        case "震动":
          temp = res.data.map(item => ({
            name: item.name,
            style: item.dust,
            datetime: item.date_time
          }));
          break;
        case "烟雾":
          temp = res.data.map(item => ({
            name: item.name,
            style: item.fog,
            datetime: item.date_time
          }));
          break;
        default:
          console.log('未知参数', this.data.currentParameter);
      }
      this.setData({
        listData: temp,
      })
    },
    fail(err) {
      console.log('请求失败', err)
    }
  })
},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
      
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    wx.cloud.init();
    let temp = "table1";
    if(this.data.currentMode == "车间一")
      temp = 'table1';
    else if(this.data.currentMode == "车间二")
      temp = 'table2';
    else if(this.data.currentMode == "车间三")
      temp = 'table3';
      const { currentPage, currentTime, currentParameter } = this.data;
      let query = wx.cloud.database().collection(temp)
        .orderBy('date_time', 'desc')
        .skip(currentPage * 20);
    
        if (currentTime) {
          const currentTimeDate = new Date(currentTime);
      
          // 转换为 yyyy-MM-dd HH:mm:ss 格式
          const year = currentTimeDate.getFullYear();
          const month = String(currentTimeDate.getMonth() + 1).padStart(2, '0');
          const day = String(currentTimeDate.getDate()).padStart(2, '0');
          const hours = String(currentTimeDate.getHours()).padStart(2, '0');
          const minutes = String(currentTimeDate.getMinutes()).padStart(2, '0');
          const seconds = String(currentTimeDate.getSeconds()).padStart(2, '0');
      
          const formattedCurrentTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
      
          query = query.where({
              date_time: wx.cloud.database().command.gte(formattedCurrentTime)
          });
      }
      query.get({
      success: res=>{
        console.log('请求成功',res);//res.data包含该记录的数据
        let temp = [];
        if(this.data.currentParameter == "温度"){
        console.log(this.data.currentParameter);
          temp = res.data.map(item => ({
          name: item.name,
          style: item.temperature,
          datetime: item.date_time
        }));
      }
        else if(this.data.currentParameter == "湿度"){
          temp = res.data.map(item => ({
          name: item.name,
          style: item.humidity,
          datetime: item.date_time
        }));
      }
        else if(this.data.currentParameter == "光强"){
         temp = res.data.map(item => ({
          name: item.name,
          style: item.light,
          datetime: item.date_time
        }));
      }
        else if(this.data.currentParameter == "震动"){
         temp = res.data.map(item => ({
          name: item.name,
          style: item.dust,
          datetime: item.date_time
        }));
      }
        else if(this.data.currentParameter == "烟雾"){
         temp = res.data.map(item => ({
          name: item.name,
          style: item.fog,
          datetime: item.date_time
        }));
      }
        this.setData({
          listData: temp,
        })
      },
      fail(err){
        console.log('请求失败',err)
      }
  })
  },
  
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})