import mqtt from'../../utils/mqtt.js';
const aliyunOpt = require('../../utils/aliyun/aliyun_connect.js');

const app = getApp();

// console.log(app.globalData.receivingdata.temperature1);
let that = null;
Page({
    sub_flag:0,
    data:{
      usr_openid:'',
      client:null,//记录重连的次数
      reconnectCounts:0,//MQTT连接的配置
      options:{
        protocolVersion: 4, //MQTT连接协议版本
        clean: false,
        reconnectPeriod: 1000, //1000毫秒，两次重新连接之间的间隔
        connectTimeout: 30 * 1000, //1000毫秒，两次重新连接之间的间隔
        resubscribe: true, //如果连接断开并重新连接，则会再次自动订阅已订阅的主题（默认true）
        clientId: 'k1640qdMy94.Wechat_app|securemode=2,signmethod=hmacsha256,timestamp=1714992100167|',
        password: '14cf9281c98e91a620cff051947b2a2ff189f14832eec32021ae0c83dedc4a00',
        username: 'Wechat_app&k1640qdMy94',
      },

      aliyunInfo: {
        productKey: 'k1640qdMy94', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        deviceName: 'Wechat_app', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        deviceSecret: '333a64816be8558d9a9f52ca9605eaa8', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        regionId: 'cn-shanghai', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        pubTopic: '/k1640qdMy94/Wechat_app/user/update', //发布消息的主题
        subTopic: '/k1640qdMy94/Wechat_app/user/get', //订阅消息的主题
      },
      onShow(){
        
        
      }
    },
    rehandlesubscribe: function(){
      wx.showModal({
        title: '温馨提示',
        content: '是否同意接受订阅消息',
        confirmText:"同意",
        cancelText:"拒绝",
        success: function (res) {
            if (res.confirm) {
               //调用订阅消息
                console.log('用户点击确定');
                //调用订阅
                that.handleSubscribe();
            } else if (res.cancel) {
                console.log('用户点击取消');
                ///显示第二个弹说明一下
                wx.showModal({
                  title: '温馨提示',
                  content: '拒绝后您将无法获取实时工厂警告提醒',
                  confirmText:"知道了",
                  showCancel:false,
                  success: function (res) {
                    ///点击知道了的后续操作 
                    ///如跳转首页面 
                  }
              });
            }
        }
    })
    },
    handleSubscribe: function() {
      wx.requestSubscribeMessage({
        tmplIds: ['h-WWOIumEJHf5XI1ng1BIJj58kiC_5fILCfKbjhaI-M'],
        success (res) {
          wx.request
          console.log(res)
          res === {
             errMsg: "requestSubscribeMessage:ok",
             "zun-LzcQyW-edafCVvzPkK4de2Rllr1fFpw2A_x0oXE": "accept"
          }
        }
      })
    },
  onLoad:function(){
    wx.getUserInfo({
      //成功后会返回
      success:(res)=>{
        console.log(res);
        // 把你的用户信息存到一个变量中方便下面使用
        let userInfo= res.userInfo
        //获取openId（需要code来换取）这是用户的唯一标识符
        // 获取code值
        wx.login({
          //成功放回
          success:(res)=>{
            console.log(res);
            let code=res.code
            // 通过code换取openId
            wx.request({
              url: `https://api.weixin.qq.com/sns/jscode2session?appid=wx4f491e3d7d8db985&secret=3d3f4f2650468ded10562c78e054e3f4&js_code=${code}&grant_type=authorization_code`,
              success:(res)=>{
                console.log("登录成功"+res);
                this.data.usr_openid =res.data.openid;
                console.log(this.data.usr_openid);  
              }
            })
          }
        })

      }
    }),
    wx.showModal({
      title: '温馨提示',
      content: '是否同意接受订阅消息',
      confirmText:"同意",
      cancelText:"拒绝",
      success: function (res) {
          if (res.confirm) {
             //调用订阅消息
              console.log('用户点击确定');
              //调用订阅
              that.handleSubscribe();
          } else if (res.cancel) {
              console.log('用户点击取消');
              ///显示第二个弹说明一下
              wx.showModal({
                title: '温馨提示',
                content: '拒绝后您将无法获取实时工厂警告提醒',
                confirmText:"知道了",
                showCancel:false,
                success: function (res) {
                  ///点击知道了的后续操作 
                  ///如跳转首页面 
                }
            });
          }
      }
  }),
    wx.cloud.init();
    that = this;
    let clientOpt = aliyunOpt.getAliyunIotMqttClient({
      productKey: that.data.aliyunInfo.productKey,
      deviceName: that.data.aliyunInfo.deviceName,
      deviceSecret: that.data.aliyunInfo.deviceSecret,
      regionId: that.data.aliyunInfo.regionId,
      port: that.data.aliyunInfo.port,
    });

    console.log("get data:" + JSON.stringify(clientOpt));
    let host = 'wxs://' + clientOpt.host;
    
    this.setData({
      'options.clientId': clientOpt.clientId,
      'options.password': clientOpt.password,
      'options.username': clientOpt.username,
    })
    console.log("this.data.options host:" + host);
    console.log("this.data.options data:" + JSON.stringify(this.data.options));
    // wx.requestSubscribeMessage({
    //   tmplIds: ['pDZvTwhhP_DSZr0IuP-Hz57JwlswfLUihTxS2Xx7Bv8'],
    //   success (res) { 
    //     console.log("订阅成功："+JSON.stringify(res))
    //   },
    //   fail(res){
    //     console.log("订阅失败："+JSON.stringify(res))
    //   }
    // }),
    //访问服务器
    this.data.client = mqtt.connect(host, this.data.options);
    app.globalData.receivedata.cli = this.data.client;
    this.data.client.on('connect', function (connack) {
      wx.showToast({
        title: '连接成功'
      })
      console.log("连接成功");
    })

    const db = wx.cloud.database(); 
    //接收消息监听
    this.data.client.on("message", function (topic, payload) {
      console.log(" 收到 topic:" + topic + " , payload :" + payload);
      console.log("获取openid是"+that.data.usr_openid);
      app.globalData.receivedata.receive_text=payload.toString();
      if(JSON.parse(payload).woring==1){
        wx.cloud.callFunction({
          name: 'cloudbase_module',
          data: {
            name: 'wx_message_send_message',
            data: {
              template_id: "h-WWOIumEJHf5XI1ng1BIJj58kiC_5fILCfKbjhaI-M", // 所需下发的订阅模板id
              page: "", //点击模板卡片后的跳转页面，仅限本小程序内的页面。支持带参数,（示例index?foo=bar）。该字段不填则模板无跳转
              touser: that.data.usr_openid, //接收者（用户）的 openid
              data:{ "thing1": { "value": JSON.parse(payload).zd_id},"time3":{"value": JSON.parse(payload).date_time},"thing5":{"value": JSON.parse(payload).type} }, //模板内容，格式形如 { "key1": { "value": any }, "key2": { "value": any } }的object
              miniprogram_state:"trial", //跳转小程序类型：developer为开发版；trial为体验版；formal为正式版；默认为正式版
              lang:"zh_CN" //进入小程序查看”的语言类型，支持zh_CN(简体中文)、en_US(英文)、zh_HK(繁体中文)、zh_TW(繁体中文)，默认为zh_CN
            },
          },
          success: (res) => {
            console.log('综合结果', res.result.result);
            console.log('错误码', res.result.errcode);
            console.log('错误信息', res.result.errmsg);
          },
        });
      }
      //节点1
      if(JSON.parse(payload).zd_id == 1){
      app.globalData.receivedata.temperature1=JSON.parse(payload).temperature;
      app.globalData.receivedata.humidity1=JSON.parse(payload).humidity;
      app.globalData.receivedata.light1=JSON.parse(payload).light;
      app.globalData.receivedata.dust1=JSON.parse(payload).dust;
      app.globalData.receivedata.fog1=JSON.parse(payload).fog;
      db.collection('table1').add({
      data:{
        //写新增的字段名：值
      name:"车间一",
      id:JSON.parse(payload).id,
      date_time:JSON.parse(payload).date_time,
      temperature:JSON.parse(payload).temperature,
      humidity:JSON.parse(payload).humidity,
      light:JSON.parse(payload).light,
      dust:JSON.parse(payload).dust,
      fog:JSON.parse(payload).fog,
        }
        }).then(res=>{
        console.log(res.data)
        })
    }
    else if(JSON.parse(payload).zd_id == 2){
      //节点2
      app.globalData.receivedata.temperature2=JSON.parse(payload).temperature;
      app.globalData.receivedata.humidity2=JSON.parse(payload).humidity;
      app.globalData.receivedata.light2=JSON.parse(payload).light;
      app.globalData.receivedata.dust2=JSON.parse(payload).dust;
      app.globalData.receivedata.fog2=JSON.parse(payload).fog;
      db.collection('table2').add({
        data:{
          //写新增的字段名：值
        name:"车间二",
        id:JSON.parse(payload).id,
        date_time:JSON.parse(payload).date_time,
        temperature:JSON.parse(payload).temperature,
        humidity:JSON.parse(payload).humidity,
        light:JSON.parse(payload).light,
        dust:JSON.parse(payload).dust,
        fog:JSON.parse(payload).fog,
          }
          }).then(res=>{
          console.log(res.data)
          })
    }
    else if(JSON.parse(payload).zd_id == 3){
      //节点3
      app.globalData.receivedata.temperature3=JSON.parse(payload).temperature;
      app.globalData.receivedata.humidity3=JSON.parse(payload).humidity;
      app.globalData.receivedata.light3=JSON.parse(payload).light;
      app.globalData.receivedata.dust3=JSON.parse(payload).dust;
      app.globalData.receivedata.fog3=JSON.parse(payload).fog;
      db.collection('table3').add({
        data:{
          //写新增的字段名：值
        name:"车间三",
        id:JSON.parse(payload).id,
        date_time:JSON.parse(payload).date_time,
        temperature:JSON.parse(payload).temperature,
        humidity:JSON.parse(payload).humidity,
        light:JSON.parse(payload).light,
        dust:JSON.parse(payload).dust,
        fog:JSON.parse(payload).fog,
          }
          }).then(res=>{
          console.log(res.data)
          })
    } 
      that.setData({
        //转换成JSON格式的数据进行读取
        temperature1:app.globalData.receivedata.temperature1,
        humidity1:app.globalData.receivedata.humidity1,
        light1:app.globalData.receivedata.light1,
        dust1:app.globalData.receivedata.dust1,
        fog1:app.globalData.receivedata.fog1,
        receive_text:app.globalData.receivedata.receive_text
      })
/*       wx.showModal({
        content: " 收到topic:[" + topic + "], payload :[" + payload + "]",
        showCancel: false,
      }); */
    });

    //服务器连接异常的回调
    that.data.client.on("error", function (error) {
      console.log(" 服务器 error 的回调" + error)

    })
    //服务器重连连接异常的回调
    that.data.client.on("reconnect", function () {
      console.log(" 服务器 reconnect的回调")

    })
    //服务器连接异常的回调
    that.data.client.on("offline", function (errr) {
      console.log(" 服务器offline的回调")
    })
  },
  onClickOpen() {
    that.sendCommond('history_echo1', 1);
  },
  onClickOff() {
    that.sendCommond('set', 0);
  },

  sendCommond(cmd, data) {
    let sendData = {
      cmd: cmd,
      data: data,
    };

//此函数是订阅的函数，因为放在访问服务器的函数后面没法成功订阅topic，因此把他放在这个确保订阅topic的时候已成功连接服务器
//订阅消息函数，订阅一次即可 如果云端没有订阅的话，需要取消注释，等待成功连接服务器之后，在随便点击（开灯）或（关灯）就可以订阅函数
  this.data.client.subscribe(this.data.aliyunInfo.subTopic,function(err){
      if(!err){
        console.log("发送成功");
      };
      wx.showModal({
        content: "发送成功",
        showCancel: false,
      })
    }
  ) 
    

    //发布消息
    if (this.data.client && this.data.client.connected) {
      this.data.client.publish(this.data.aliyunInfo.pubTopic, JSON.stringify(sendData));
      console.log("************************")
      console.log(this.data.aliyunInfo.pubTopic)
      console.log(JSON.stringify(sendData))
    } else {
      wx.showToast({
        title: '请先连接服务器',
        icon: 'none',
        duration: 2000
      })
    }
  }
})