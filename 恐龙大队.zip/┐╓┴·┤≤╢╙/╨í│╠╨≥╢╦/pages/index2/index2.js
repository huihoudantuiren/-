import mqtt from'../../utils/mqtt.js';
const aliyunOpt = require('../../utils/aliyun/aliyun_connect.js');

const app = getApp();

let that = null;
Page({
    sub_flag:0,
    data:{
      temperature2:'',
      humidity2:'',
      light2:'',
      dust2:"",
      fog2:'',
      client:1,//记录重连的次数
      reconnectCounts:0,//MQTT连接的配置
      options:{
        protocolVersion: 4, //MQTT连接协议版本
        clean: false,
        reconnectPeriod: 1000, //1000毫秒，两次重新连接之间的间隔
        connectTimeout: 30 * 1000, //1000毫秒，两次重新连接之间的间隔
        resubscribe: true, //如果连接断开并重新连接，则会再次自动订阅已订阅的主题（默认true）
        clientId: 'k1640qdMy94.Wechat_app|securemode=2,signmethod=hmacsha256,timestamp=1714992100167|',
        password: '14cf9281c98e91a620cff051947b2a2ff189f14832eec32021ae0c83dedc4a00',
        username: 'Wechat_app&k1640qdMy94',
      },

      aliyunInfo: {
        productKey: 'k1640qdMy94', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        deviceName: 'Wechat_app', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        deviceSecret: '333a64816be8558d9a9f52ca9605eaa8', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        regionId: 'cn-shanghai', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        pubTopic: '/k1640qdMy94/Wechat_app/user/update', //发布消息的主题
        subTopic: '/k1640qdMy94/Wechat_app/user/get', //订阅消息的主题
      },
    },
  onShow: function(){
    console.log(app.globalData.receivedata.temperature2);
    this.data.client = app.globalData.receivedata.cli;
    },
  onLoad: function(){
    console.log(app.globalData.receivedata.temperature2);
    this.data.client = app.globalData.receivedata.cli;
    // 每隔一秒刷新数据
    this.refreshInterval = setInterval(() => {
      this.setData({
        temperature2:app.globalData.receivedata.temperature2,
        humidity2: app.globalData.receivedata.humidity2,
        light2: app.globalData.receivedata.light2,
        dust2: app.globalData.receivedata.dust2,
        fog2: app.globalData.receivedata.fog2,
        receive_text:app.globalData.receivedata.receive_text,
      });
    }, 500);
  },
  onUnload: function() {
    // 页面卸载时清除定时器，防止内存泄漏
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
  },
  onClickOpen() {
    that = this;
    that.sendCommond('history_echo2', 1);
  },
  onClickOff() {
    that = this;
    that.sendCommond('set', 0);
  },
  sendCommond(cmd, data) {
    let sendData = {
      cmd: cmd,
      data: data,
    };

//此函数是订阅的函数，因为放在访问服务器的函数后面没法成功订阅topic，因此把他放在这个确保订阅topic的时候已成功连接服务器
//订阅消息函数，订阅一次即可 如果云端没有订阅的话，需要取消注释，等待成功连接服务器之后，在随便点击（开灯）或（关灯）就可以订阅函数
  this.data.client.subscribe(this.data.aliyunInfo.subTopic,function(err){
      if(!err){
        console.log("发送成功");
      };
      wx.showModal({
        content: "发送成功",
        showCancel: false,
      })
    }
  ) 
    

    //发布消息
    if (this.data.client && this.data.client.connected) {
      this.data.client.publish(this.data.aliyunInfo.pubTopic, JSON.stringify(sendData));
      console.log("************************")
      console.log(this.data.aliyunInfo.pubTopic)
      console.log(JSON.stringify(sendData))
    } else {
      wx.showToast({
        title: '请先连接服务器',
        icon: 'none',
        duration: 2000
      })
    }
  }
})