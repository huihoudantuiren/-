const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

const db = new sqlite3.Database('./database.db');

db.serialize(() => {
  db.run("CREATE TABLE IF NOT EXISTS Table1 (date_time TEXT, temperature REAL, light REAL, humidity REAL, fog REAL, dust REAL)");
  db.run("CREATE TABLE IF NOT EXISTS Table2 (date_time TEXT, temperature REAL, light REAL, humidity REAL, fog REAL, dust REAL)");
  db.run("CREATE TABLE IF NOT EXISTS Table3 (date_time TEXT, temperature REAL, light REAL, humidity REAL, fog REAL, dust REAL)");
});

app.post('/saveData', (req, res) => {
  const { zd_id, date_time, temperature, light, humidity, fog, dust } = req.body;
  const tableName = `Table${zd_id}`;
  const stmt = db.prepare(`INSERT INTO ${tableName} VALUES (?, ?, ?, ?, ?, ?)`);
  stmt.run(date_time, temperature, light, humidity, fog, dust, (err) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json({ message: 'Data saved successfully' });
    }
  });
  stmt.finalize();
});

app.get('/getHistory', (req, res) => {
  const tableName = req.query.table || 'Table1';
  const filterTime = req.query.filterTime;
  const page = parseInt(req.query.page) || 1;
  const pageSize = parseInt(req.query.pageSize) || 10;
  const offset = (page - 1) * pageSize;

  let countQuery = `SELECT COUNT(*) AS count FROM ${tableName}`;
  let dataQuery = `SELECT date_time, temperature, light, humidity, fog, dust FROM ${tableName} ORDER BY date_time DESC LIMIT ? OFFSET ?`;

  if (filterTime) {
    countQuery += ` WHERE date_time > ?`;
    dataQuery = `SELECT date_time, temperature, light, humidity, fog, dust FROM ${tableName} WHERE date_time > ? ORDER BY date_time DESC LIMIT ? OFFSET ?`;
  }

  db.get(countQuery, filterTime ? [filterTime] : [], (err, row) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }

    const totalItems = row.count;

    db.all(dataQuery, filterTime ? [filterTime, pageSize, offset] : [pageSize, offset], (err, rows) => {
      if (err) {
        res.status(500).json({ error: err.message });
      } else {
        res.json({
          totalItems: totalItems,
          data: rows
        });
      }
    });
  });
});

app.get('/getParams', (req, res) => {
  const tableName = req.query.table || 'Table1';
  const param = req.query.param || 'temperature'; // Default to 'temperature' if no param is specified
  const columns = ['date_time', param].join(', ');

  const filterTime = req.query.filterTime;

  let dataQuery = `SELECT ${columns} FROM ${tableName} ORDER BY date_time DESC`;

  if (filterTime) {
    dataQuery = `SELECT ${columns} FROM ${tableName} WHERE date_time > ? ORDER BY date_time DESC`;
  }

  db.all(dataQuery, filterTime ? [filterTime] : [], (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json({
        data: rows
      });
    }
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);
});
