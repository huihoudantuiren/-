const iot = require('../');


// init device and connect linkplatform
const device = iot.device({
  "PRODUCTKEY": "a1ouyopKiEU",
  "DeviceName": "device1",
  "DeviceSecret": "mi9FfuIN28blO1n4oSytBi2kvcWoJzTj"
});

device.on('connect', () => {
  console.log('>>>>>device connect succeed');
  // subscribe remote Configuration change
  device.onConfig((res) => {
    console.log("remote Configuration change:",res);
  });
});