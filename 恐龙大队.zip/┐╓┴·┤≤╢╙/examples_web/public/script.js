window.onload = function() {
  const statusElement = document.getElementById('status');
  const messagesElement = document.getElementById('messages');
  const nodeElements = {
    1: document.getElementById('node1'),
    2: document.getElementById('node2'),
    3: document.getElementById('node3')
  };

  const sdk_device2 = {
    productKey: 'k1640qdMy94',
    deviceName: 'Web_page',
    deviceSecret: '411cca4d5ca3ca52778ddb91ce41231c',
  }
  let device;

  function connect(){
    if(!device){
      updateStatus('开始连接....');
      device = iot.device(sdk_device2);
      device.on('connect', (res) => {
        updateStatus('连接成功');
        device.subscribe('/k1640qdMy94/Web_page/user/get', (err) => {
          if (err) {
            updateStatus('订阅主题失败: ' + err);
          } else {
            updateStatus('订阅主题成功');
          }
        });
      });
      device.on('error', (err) => {
        updateStatus('连接错误: ' + err);
      });
      device.on('message', (topic, payload) => {
        handleMessage(payload.toString());
      });
    }  
  }

  function postEvent(){
    device.publish('/k1640qdMy94/Web_page/user/update', JSON.stringify({
      power: 10,
    }), (err, res) => {
      if (err) {
        updateStatus("发布消息错误: " + err);
      } else {
        updateStatus("消息发布成功");
      }
    });
  }

  function updateStatus(message) {
    if (statusElement.innerText !== '连接成功' && statusElement.innerText !== '订阅主题成功') {
      statusElement.innerText = message;
    }
  }

  function getCellStyle(parameter, value) {
    const thresholds = {
      '温度': 40,
      '湿度': 70,
      '光强': 300,
      '尘埃': 100,
      '烟雾': 50
    };
    return value > thresholds[parameter] ? 'red' : 'white';
  }

  function handleMessage(message) {
    try {
      const data = JSON.parse(message);
      const { zd_id, date_time, temperature, light, humidity, fog, dust } = data;
      if (nodeElements[zd_id]) {
        nodeElements[zd_id].innerHTML = `
          <div class="table">
            <div class="table-row">
              <div class="table-cell" colspan="2"><strong>节点 ${zd_id}</strong></div>
            </div>
            <div class="table-row">
              <div class="table-cell">时间</div>
              <div class="table-cell">${date_time}</div>
            </div>
            <div class="table-row">
              <div class="table-cell">温度</div>
              <div class="table-cell" style="color: ${getCellStyle('温度', temperature)}">${temperature} °C</div>
            </div>
            <div class="table-row">
              <div class="table-cell">光强</div>
              <div class="table-cell" style="color: ${getCellStyle('光强', light)}">${light} lx</div>
            </div>
            <div class="table-row">
              <div class="table-cell">湿度</div>
              <div class="table-cell" style="color: ${getCellStyle('湿度', humidity)}">${humidity} %</div>
            </div>
            <div class="table-row">
              <div class="table-cell">烟雾</div>
              <div class="table-cell" style="color: ${getCellStyle('烟雾', fog)}">${fog} ppm</div>
            </div>
            <div class="table-row">
              <div class="table-cell">尘埃</div>
              <div class="table-cell" style="color: ${getCellStyle('尘埃', dust)}">${dust} hz</div>
            </div>
          </div>
        `;
        saveToDatabase(data);
      }
    } catch (error) {
      console.error('Error parsing message', error);
    }
  }

  function saveToDatabase(data) {
    fetch('/saveData', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    }).then(response => response.json())
      .then(result => {
        console.log('Data saved:', result);
        loadHistory();
      })
      .catch(error => {
        console.error('Error saving data:', error);
      });
  }

    let filterTime = null;
    let currentPage = 1;
    let pageSize = 10;
    let totalRecords = 0;
    let totalPages = 0;

    document.getElementById('clsButton').addEventListener('click', () => {
      filterTime = new Date().toISOString();
      loadHistory();
      check();
    });

    document.getElementById('getButton').addEventListener('click', () => {
      const loading = document.getElementById('loading');
      loading.style.display = 'block';
      
      setTimeout(() => {
          filterTime = null;
          loadHistory();
          loading.style.display = 'none';
          alert('获取完成');
      }, 5000);
      check();
  });

    function loadHistory() {
      const selectedTable = document.getElementById('tableSelect').value;
      let url = `/getHistory?table=${selectedTable}&page=${currentPage}&pageSize=${pageSize}`;
      
      if (filterTime) {
        url += `&filterTime=${filterTime}`;
      }

      fetch(url)
        .then(response => response.json())
        .then(data => {
          totalRecords = data.totalItems;
          totalPages = Math.ceil(totalRecords / pageSize);
          const historyElement = document.getElementById('history').getElementsByTagName('tbody')[0];
          let historyHtml = '';
          data.data.forEach(record => {
            historyHtml += `
              <tr>
                <td>${record.date_time}</td>
                <td>${record.temperature} °C</td>
                <td>${record.light} lx</td>
                <td>${record.humidity} %</td>
                <td>${record.fog} ppm</td>
                <td>${record.dust} hz</td>
              </tr>
            `;
          });
          historyElement.innerHTML = historyHtml;
          document.getElementById('pageInfo').innerText = `第 ${currentPage} 页 / 共 ${totalPages} 页 `;
        })
        .catch(error => {
          console.error('Error loading history:', error);
        });
    }

function nextPage() {
  if (currentPage < totalPages) {
    currentPage++;
    loadHistory();
  }
}

function previousPage() {
  if (currentPage > 1) {
    currentPage--;
    loadHistory();
  }
}

  let chartInstance = null;

  function check() {
    const tableName = document.getElementById('tableSelect1').value;; // Specify your table name
    const param = document.getElementById('tableSelect2').value;; // Specify the parameter you want to plot

    fetch(`/getParams?table=${tableName}&param=${param}`)
    .then(response => response.json())
    .then(data => {
      const filteredData = data.data.filter(item => {
        const itemDate = new Date(item.date_time);
        return itemDate >= new Date(filterTime) && itemDate <= new Date('2999-12-30 23:59:59');
      });

      const labels = filteredData.map(item => item.date_time);
      const values = filteredData.map(item => item[param]);

      if (labels.length !== values.length) {
        console.error('Data length mismatch between labels and values');
        return;
      }

        const ctx = document.getElementById('myChart').getContext('2d');

        if (chartInstance) {
          chartInstance.destroy();
        }

        chartInstance = new Chart(ctx, {
          type: 'line',
          data: {
            labels: labels,
            datasets: [{
              label: param,
              data: values,
              borderColor: 'rgba(75, 192, 192, 1)',
              borderWidth: 1,
              fill: false
            }]
          },
          options: {
            scales: {
              x: {
                type: 'time',
                time: {
                  parser: 'yyyy-MM-dd HH:mm:ss',
                  tooltipFormat: 'MMM dd, yyyy HH:mm:ss',
                  displayFormats: {
                    millisecond: 'HH:mm:ss',
                    second: 'HH:mm:ss',
                    minute: 'HH:mm',
                    hour: 'HH:mm',
                    day: 'MMM dd',
                    week: 'MMM dd',
                    month: 'yyyy-MM',
                    quarter: 'yyyy-MM',
                    year: 'yyyy'
                  }
                },
                title: {
                  display: true,
                  color: 'white',  // 设置x轴标签颜色
                  text: 'Date Time'
                },
                ticks: {
                  color: 'white',  // 设置x轴标签颜色
                  font: {
                    size: 14,  // 设置x轴标签字体大小
                  },
                },
                grid: {
                  color: 'rgba(200, 200, 200, 0.2)',  // 设置x轴网格线颜色
                }
              },
              y: {
                title: {
                  display: true,
                  color: 'white',  // 设置x轴标签颜色
                  text: param
                },
                ticks: {
                  color: 'white',  // 设置y轴标签颜色
                  font: {
                    size: 14,  // 设置y轴标签字体大小
                  },
                },
                grid: {
                  color: 'rgba(200, 200, 200, 0.2)',  // 设置y轴网格线颜色
                }
              }
            },
            plugins: {
              legend: {
                display: true
              },
              tooltip: {
                callbacks: {
                  label: function(context) {
                    return `${context.parsed.y} ${param}`;
                  }
                }
              }
            }
          }
        });
      })
      .catch(error => console.error('Error fetching data:', error));
  }

  function checkAndLoadHistory() {
  const startTime = document.getElementById('startTime').value;
  const endTime = document.getElementById('endTime').value;
  const selectedTable1 = document.getElementById('tableSelect1').value;
  const selectedTable2 = document.getElementById('tableSelect2').value;

  console.log(filterTime);
  console.log(startTime);
  console.log(endTime);
  console.log(selectedTable1);
  console.log(selectedTable2);

  if (!startTime || !endTime) {
    alert("请输入起始时间和结束时间");
    return;
  }

  if (new Date(startTime) >= new Date(endTime)) {
    alert("结束时间必须大于起始时间");
    return;
  }

  if(new Date(filterTime)>new Date(endTime))
  {
    alert("该时间段数据清空");
    if (chartInstance) {
      chartInstance.destroy();
    }
    return;
  }
  if(new Date(filterTime)>new Date(startTime))
  {
    startTime=filterTime;
  }
  
  fetch(`/getParams?table=${selectedTable1}&param=${selectedTable2}`)
    .then(response => response.json())
    .then(data => {
      const filteredData = data.data.filter(item => {
        const itemDate = new Date(item.date_time);
        return itemDate >= new Date(startTime) && itemDate <= new Date(endTime);
      });

      const labels = filteredData.map(item => item.date_time);
      const values = filteredData.map(item => item[selectedTable2]);

      if (labels.length !== values.length) {
        console.error('Data length mismatch between labels and values');
        return;
      }

      const ctx = document.getElementById('myChart').getContext('2d');

      if (chartInstance) {
        chartInstance.destroy();
      }

      chartInstance = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: selectedTable2,
            data: values,
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1,
            fill: false
          }]
        },
        options: {
          scales: {
            x: {
              type: 'time',
              time: {
                parser: 'yyyy-MM-dd HH:mm:ss',
                tooltipFormat: 'MMM dd, yyyy HH:mm:ss',
                displayFormats: {
                  millisecond: 'HH:mm:ss',
                  second: 'HH:mm:ss',
                  minute: 'HH:mm',
                  hour: 'HH:mm',
                  day: 'MMM dd',
                  week: 'MMM dd',
                  month: 'yyyy-MM',
                  quarter: 'yyyy-MM',
                  year: 'yyyy'
                }
              },
              title: {
                display: true,
                color: 'white',  // 设置x轴标签颜色
                text: 'Date Time'
              },
              ticks: {
                color: 'white',  // 设置x轴标签颜色
                font: {
                  size: 14,  // 设置x轴标签字体大小
                },
              },
              grid: {
                color: 'rgba(200, 200, 200, 0.2)',  // 设置x轴网格线颜色
              }
            },
            y: {
              title: {
                display: true,
                text: selectedTable2,
                color: 'white',  // 设置x轴标签颜色
              },
              ticks: {
                color: 'white',  // 设置y轴标签颜色
                font: {
                  size: 14,  // 设置y轴标签字体大小
                },
              },
              grid: {
                color: 'rgba(200, 200, 200, 0.2)',  // 设置y轴网格线颜色
              }
            }
          },
          plugins: {
            legend: {
              display: true
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  return `${context.parsed.y} ${selectedTable2}`;
                }
              }
            }
          }
        }
      });
    })
    .catch(error => console.error('Error fetching data:', error));
}


  // 初始加载默认表格
  document.addEventListener('DOMContentLoaded', () => {
    loadHistory();
  });

  
  // 自动连接并订阅
  connect();
  loadHistory();

  // Make functions accessible globally
  window.postEvent = postEvent;
  window.previousPage = previousPage;
  window.nextPage = nextPage;
  window.loadHistory = loadHistory;
  window.checkAndLoadHistory = checkAndLoadHistory;
  window.check = check;
}
