## 如何启动 

1：修改device_id_password.json，把注册的设备三元组信息填写进去
2：命令行执行 ` sh ./start.sh `

