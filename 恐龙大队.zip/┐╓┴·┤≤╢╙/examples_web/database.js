const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database(':memory:'); // 使用内存数据库，方便开发和测试

// 创建表
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS sensor_data (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      zd_id INTEGER,
      date_time TEXT,
      temperature REAL,
      light REAL,
      humidity REAL,
      fog REAL,
      dust REAL
    )
  `);
});

// 保存数据
function saveData(data) {
  const stmt = db.prepare(`
    INSERT INTO sensor_data (zd_id, date_time, temperature, light, humidity, fog, dust) 
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(data.zd_id, data.date_time, data.temperature, data.light, data.humidity, data.fog, data.dust);
  stmt.finalize();
}

// 获取历史数据
function getHistory(callback) {
  db.all('SELECT * FROM sensor_data ORDER BY date_time DESC', (err, rows) => {
    if (err) {
      console.error(err);
      callback([]);
    } else {
      callback(rows);
    }
  });
}

module.exports = {
  saveData,
  getHistory
};
